import csv,json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from village_debug_camera_summary import frame_samples
from village_capture_summary import distribution
p=Path(r'D:\code\rocco-engine\examples\village\tour-capture-20261106-2240\cpu-1')
s=json.loads((p/'summary.json').read_text()); rows=list(csv.DictReader((p/'boundaries.csv').open())); cpu={int(r['frame']):r for r in csv.DictReader((p/'cpu.csv').open())}
member={m['frame']:m for m in s['membership'] if m['included']}
samples=[r for r in frame_samples(rows,s['metadata']['frequency_hz']) if r['frame'] in member]
for r in samples:
 c=cpu[r['frame']];spans={k[:-3]:float(v)/1000 for k,v in c.items() if k.endswith('_us') and k!='span_cost_us'}
 r['cpu_spans_ms']=spans;r['cpu_work_excluding_commit_ms']=sum(v for k,v in spans.items() if k!='commit')
 r['unattributed_callback_ms']=r['callback_to_commit_end_ms']-sum(spans.values())-r['begin_pass_ms']
 r['cycles']=member[r['frame']]['cycles'];r['mixed']=member[r['frame']]['mixed']
 r['time_since_capture_start_s']=(int(rows[r['frame']-1]['start_tick'])-int(rows[0]['start_tick']))/s['metadata']['frequency_hz']
fields=['interval_ms','cpu_work_excluding_commit_ms','commit_cpu_ms','callback_to_commit_end_ms','begin_pass_ms','drawable_ms','after_commit_ms','unattributed_callback_ms']
def group(g):
 return dict(frames=len(g),first_frame=g[0]['frame'],last_frame=g[-1]['frame'],slow_50ms=[r['frame'] for r in g if r['interval_ms']>=50],**{k:distribution([r[k] for r in g]) for k in fields})
result=dict(definition='Intervals use each selected engine frame to its following callback, including final route boundary. Whole mixed frames retained; a boundary frame can belong to both tours. Official combined summary uses consecutive selected callbacks, so it has one fewer interval.',combined=group(samples),tours={str(i):group([r for r in samples if i in r['cycles']]) for i in [1,2]},slowest_frames=sorted(samples,key=lambda r:r['interval_ms'],reverse=True)[:20])
for i in [1,2]:
 g=[r for r in samples if i in r['cycles']]; result['tours'][str(i)]['slowest_frames']=sorted(g,key=lambda r:r['interval_ms'],reverse=True)[:5]
(p/'frame-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
with (p/'slowest-frames.csv').open('w',newline='') as f:
 keys=['frame','cycles','steps','interval_ms','cpu_work_excluding_commit_ms','begin_pass_ms','drawable_ms','commit_cpu_ms','after_commit_ms','eye','cpu_spans_ms']
 w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows([{k:r[k] for k in keys} for r in result['slowest_frames']])
print(json.dumps(dict(combined=result['combined'],tours={k:{f:v for f,v in t.items() if f in ['frames','first_frame','last_frame','interval_ms','cpu_work_excluding_commit_ms']} for k,t in result['tours'].items()},slowest=result['slowest_frames'][:5],slowest_second=result['tours']['2']['slowest_frames'][:2]),indent=2))
