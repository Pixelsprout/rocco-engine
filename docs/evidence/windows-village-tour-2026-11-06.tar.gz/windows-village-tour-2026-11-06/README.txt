Windows village full-v1 CPU capture, 2026-11-06

Original capture files are preserved byte for byte. Absolute paths in run.json,
the original hash manifest, original analysis script and original report identify
the native capture machine; they are historical provenance, not extraction paths.
build-provenance/ contains the reused binary build logs and shader metadata.
The executable is retained locally and is not included in this data archive.
Its SHA-256 is in executable-sha256.json and run.json.

Recompute the official summary from the extracted archive directory:
python tools/village_capture_summary.py cpu-1/boundaries.csv --cpu cpu-1/cpu.csv --out recomputed-summary.json

The original launcher source-state probe failed on junction-backed submodules.
source-state.txt is the successful --ignore-submodules=all status observation.
The exact source commit, native library hashes and executable hash are retained.
No rendering changes were made.

SHA256SUMS.json hashes every other archive file using relative paths.
