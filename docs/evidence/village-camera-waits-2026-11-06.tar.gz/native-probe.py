import subprocess, os, time, json, pathlib, signal, hashlib
root=pathlib.Path('/Users/braedenfoster/playground/rocco-engine')
out=pathlib.Path('/tmp/village-stutter-native-20261106'); out.mkdir(exist_ok=False)
binary=root/'examples/village/village-wide-sweep.bin'
env=os.environ.copy()
for k in list(env):
    if k.startswith('ROCCO_'): del env[k]
env.update(ROCCO_DEBUG_CAMERA='1', ROCCO_DEBUG_CAMERA_SWEEP='1', ROCCO_CAPTURE_DEBUG_CAMERA='1', ROCCO_CAPTURE_LABELS='1', ROCCO_CAPTURE_CSV=str(out/'boundaries.csv'),ROCCO_SPANS_CSV=str(out/'cpu.csv'),ROCCO_EXIT_AFTER_FRAMES='1800',ROCCO_ASSETS=str(root/'examples/village/assets'), ROCCO_SEED='0')
manifest={'binary':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'environment':{k:v for k,v in env.items() if k.startswith('ROCCO_')},'start_monotonic_ns':time.monotonic_ns(),'limit_seconds':90}
game=trace=None
try:
    with (out/'host.log').open('w') as h,(out/'trace.log').open('w') as t,(out/'monitor.jsonl').open('w') as m:
        game=subprocess.Popen([str(binary)],cwd=root/'examples/village',env=env,stdout=h,stderr=subprocess.STDOUT)
        manifest['game_pid']=game.pid
        cmd=['xcrun','xctrace','record','--template','Metal System Trace','--instrument','Display','--instrument','Thread State Trace','--time-limit','55s','--output',str(out/'gpu.trace'),'--attach',str(game.pid)]
        manifest['trace_command']=cmd
        trace=subprocess.Popen(cmd,stdout=t,stderr=subprocess.STDOUT)
        start=time.monotonic()
        while game.poll() is None and time.monotonic()-start < 90:
            pressure=subprocess.run(['sysctl','-n','kern.memorystatus_vm_pressure_level'],capture_output=True,text=True)
            processes=subprocess.run(['ps','-axo','pid,ppid,%cpu,%mem,rss,comm'],capture_output=True,text=True).stdout.splitlines()
            top=sorted(processes[1:],key=lambda l:float(l.split()[2]),reverse=True)[:15]
            m.write(json.dumps({'tick':time.monotonic_ns(),'pressure':pressure.stdout.strip(),'top':top})+'\n');m.flush()
            if pressure.stdout.strip() not in ('1',''):
                manifest['interrupted']='memory pressure';game.terminate();break
            time.sleep(2)
        if game.poll() is None:
            manifest.setdefault('interrupted','timeout');game.terminate()
        manifest['game_exit']=game.wait(timeout=15)
        if trace.poll() is None:trace.send_signal(signal.SIGINT)
        manifest['trace_exit']=trace.wait(timeout=30)
except BaseException as e:
    manifest['failure']=repr(e)
finally:
    for p in (game,trace):
        if p and p.poll() is None:
            p.terminate()
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:p.kill();p.wait()
    manifest['end_monotonic_ns']=time.monotonic_ns()
    (out/'run.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest,indent=2))
