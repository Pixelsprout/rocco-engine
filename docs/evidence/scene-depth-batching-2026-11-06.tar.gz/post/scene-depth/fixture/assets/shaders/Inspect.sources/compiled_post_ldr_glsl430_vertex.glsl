#version 430

layout(location = 0) out vec2 v_uv;

void main()
{
    vec2 _22 = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    gl_Position = vec4((_22 * 2.0) - vec2(1.0), 0.0, 1.0);
    v_uv = _22;
}

