#version 430

struct Vertex
{
    vec3 position;
    vec3 normal;
    vec4 tangent;
    vec4 colour;
    vec2 uv;
    float time;
    vec4 draw;
    vec3 world_position;
    vec3 world_origin;
    mat3 world_to_local_direction;
};

uniform vec4 game_vertex[16];
uniform vec4 engine_vertex[16];
layout(binding = 0) uniform sampler2D game_weights_tex_game_weights_smp;

layout(location = 5) in vec4 instance_model_0;
layout(location = 6) in vec4 instance_model_1;
layout(location = 7) in vec4 instance_model_2;
layout(location = 8) in vec4 instance_model_3;
layout(location = 9) in vec3 instance_normal_0;
layout(location = 10) in vec3 instance_normal_1;
layout(location = 11) in vec3 instance_normal_2;
layout(location = 0) in vec3 position;
layout(location = 2) in vec3 normal;
layout(location = 4) in vec4 tangent;
layout(location = 1) in vec4 colour;
layout(location = 3) in vec2 uv;
layout(location = 0) out vec4 v_col;
layout(location = 4) out vec2 v_uv;
layout(location = 1) out vec3 v_nrm;
layout(location = 2) out vec3 v_geometry;
layout(location = 3) out vec3 v_world;
layout(location = 5) out vec4 v_tng;
layout(location = 6) flat out float v_time;
layout(location = 7) out vec4 v_instance_tint;
layout(location = 12) in vec4 instance_tint;

vec4 sample_weights(vec2 uv_1)
{
    return textureLod(game_weights_tex_game_weights_smp, uv_1, 0.0);
}

float param_phase()
{
    return game_vertex[1].x;
}

float param_wind()
{
    return game_vertex[0].x;
}

void rocco_vertex(inout Vertex vertex)
{
    vec2 param = vertex.uv;
    vertex.position.x += ((sin(((vertex.time * 2.0) + vertex.world_origin.x) + param_phase()) * param_wind()) * (vertex.colour.x * sample_weights(param).x));
}

void main()
{
    mat4 _126 = mat4(instance_model_0, instance_model_1, instance_model_2, instance_model_3);
    vec4 _164 = vec4(instance_normal_0, 0.0);
    vec4 _165 = vec4(instance_normal_1, 0.0);
    vec4 _166 = vec4(instance_normal_2, 0.0);
    mat4 _168 = mat4(_164, _165, _166, vec4(0.0, 0.0, 0.0, 1.0));
    Vertex param = Vertex(position, normal, tangent, colour, uv, engine_vertex[12].x, engine_vertex[13], (_126 * vec4(position, 1.0)).xyz, instance_model_3.xyz, transpose(mat3(_164.xyz, _165.xyz, _166.xyz)));
    rocco_vertex(param);
    vec4 _249 = vec4(param.position, 1.0);
    gl_Position = (mat4(engine_vertex[0], engine_vertex[1], engine_vertex[2], engine_vertex[3]) * _126) * _249;
    v_col = param.colour;
    v_uv = param.uv;
    v_nrm = (_168 * vec4(param.normal, 0.0)).xyz;
    v_geometry = (_168 * vec4(normal, 0.0)).xyz;
    v_world = (_126 * _249).xyz;
    v_tng = vec4((_126 * vec4(param.tangent.xyz, 0.0)).xyz, param.tangent.w * ((determinant(mat3(instance_model_0.xyz, instance_model_1.xyz, instance_model_2.xyz)) < 0.0) ? (-1.0) : 1.0));
    v_time = engine_vertex[12].x;
    v_instance_tint = instance_tint;
    gl_Position.z = 2.0 * gl_Position.z - gl_Position.w;
}

