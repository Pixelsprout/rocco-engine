#version 430

struct SurfaceInput
{
    vec4 colour;
    vec2 uv;
    vec3 world;
    vec3 geometric_normal;
    float time;
};

struct Surface
{
    vec3 base_colour;
    float opacity;
    float occlusion;
    float metallic;
    float roughness;
    vec3 emission;
    vec3 normal;
    bool unlit;
};

uniform vec4 game_fragment[16];
uniform vec4 fs_params[6];
layout(binding = 0) uniform sampler2D base_tex_base_smp;
layout(binding = 1) uniform sampler2D metallic_roughness_tex_metallic_roughness_smp;
layout(binding = 2) uniform sampler2D emissive_tex_emissive_smp;
layout(binding = 3) uniform sampler2D normal_tex_normal_smp;
layout(binding = 4) uniform sampler2D occlusion_tex_occlusion_smp;

layout(location = 1) in vec3 v_nrm;
layout(location = 5) in vec4 v_tng;
layout(location = 4) in vec2 v_uv;
layout(location = 0) in vec4 v_col;
layout(location = 3) in vec3 v_world;
layout(location = 2) in vec3 v_geometry;
layout(location = 6) flat in float v_time;
layout(location = 7) in vec4 v_instance_tint;
layout(location = 0) out float selected_coverage;
layout(location = 1) out float selected_depth;

vec3 safe_normalize(vec3 v)
{
    return v / vec3(max(length(v), 9.9999999747524270787835121154785e-07));
}

vec3 surface_normal()
{
    vec3 param = v_nrm;
    vec3 _67 = safe_normalize(param);
    vec3 param_1 = v_tng.xyz - (_67 * dot(_67, v_tng.xyz));
    vec3 _81 = safe_normalize(param_1);
    vec3 _111 = (texture(normal_tex_normal_smp, v_uv).xyz * 2.0) - vec3(1.0);
    vec2 _122 = _111.xy * fs_params[4].x;
    vec3 param_2 = ((_81 * _122.x) + ((cross(_67, _81) * v_tng.w) * _122.y)) + (_67 * _111.z);
    return safe_normalize(param_2);
}

Surface imported_surface()
{
    vec4 _188 = ((v_col * fs_params[0]) * v_instance_tint) * texture(base_tex_base_smp, v_uv);
    vec4 _203 = texture(metallic_roughness_tex_metallic_roughness_smp, v_uv);
    return Surface(_188.xyz, _188.w, mix(1.0, texture(occlusion_tex_occlusion_smp, v_uv).x, fs_params[4].y), fs_params[1].y * _203.z, fs_params[1].x * _203.y, (fs_params[2].xyz * texture(emissive_tex_emissive_smp, v_uv).xyz) + fs_params[3].xyz, surface_normal(), fs_params[1].z != 0.0);
}

SurfaceInput surface_input()
{
    vec3 param = v_geometry;
    return SurfaceInput(v_col, v_uv, v_world, safe_normalize(param), v_time);
}

vec4 param_leaf_tint()
{
    return game_fragment[0];
}

void rocco_surface(inout Surface surface, SurfaceInput data)
{
    surface.base_colour *= param_leaf_tint().xyz;
}

float surface_coverage()
{
    Surface _268 = imported_surface();
    vec3 _365 = _268.base_colour;
    float _366 = _268.opacity;
    float _367 = _268.occlusion;
    float _368 = _268.metallic;
    float _369 = _268.roughness;
    vec3 _370 = _268.emission;
    vec3 _371 = _268.normal;
    bool _372 = _268.unlit;
    Surface param = Surface(_365, _366, _367, _368, _369, _370, _371, _372);
    SurfaceInput param_1 = surface_input();
    rocco_surface(param, param_1);
    _365 = param.base_colour;
    _366 = param.opacity;
    _367 = param.occlusion;
    _368 = param.metallic;
    _369 = param.roughness;
    _370 = param.emission;
    _371 = param.normal;
    _372 = param.unlit;
    return param.opacity;
}

void main()
{
    float _280 = surface_coverage();
    bool _283 = fs_params[4].z == 1.0;
    bool _290;
    if (_283)
    {
        _290 = _280 < fs_params[1].w;
    }
    else
    {
        _290 = _283;
    }
    if (_290)
    {
        discard;
    }
    selected_coverage = 1.0;
    selected_depth = gl_FragCoord.z;
}

