#version 430

struct Vertex
{
    vec3 position;
    vec3 normal;
    vec4 tangent;
    vec4 colour;
    vec2 uv;
    float time;
    vec4 draw;
    vec3 world_position;
    vec3 world_origin;
    mat3 world_to_local_direction;
};

uniform vec4 game_vertex[16];
uniform vec4 engine_vertex[16];
uniform vec4 engine_skin[256];
layout(binding = 0) uniform sampler2D game_weights_tex_game_weights_smp;

layout(location = 5) in uvec4 joint_ids;
layout(location = 6) in vec4 joint_weights;
layout(location = 0) in vec3 position;
layout(location = 2) in vec3 normal;
layout(location = 4) in vec4 tangent;
layout(location = 1) in vec4 colour;
layout(location = 3) in vec2 uv;
layout(location = 0) out vec4 v_col;
layout(location = 4) out vec2 v_uv;
layout(location = 1) out vec3 v_nrm;
layout(location = 2) out vec3 v_geometry;
layout(location = 3) out vec3 v_world;
layout(location = 5) out vec4 v_tng;
layout(location = 6) flat out float v_time;
layout(location = 7) out vec4 v_instance_tint;

vec4 sample_weights(vec2 uv_1)
{
    return textureLod(game_weights_tex_game_weights_smp, uv_1, 0.0);
}

float param_phase()
{
    return game_vertex[1].x;
}

float param_wind()
{
    return game_vertex[0].x;
}

void rocco_vertex(inout Vertex vertex)
{
    vec2 param = vertex.uv;
    vertex.position.x += ((sin(((vertex.time * 2.0) + vertex.world_origin.x) + param_phase()) * param_wind()) * (vertex.colour.x * sample_weights(param).x));
}

void main()
{
    mat4 _101 = mat4(engine_vertex[4], engine_vertex[5], engine_vertex[6], engine_vertex[7]);
    mat4 _105 = mat4(engine_vertex[8], engine_vertex[9], engine_vertex[10], engine_vertex[11]);
    mat4 _125 = mat4(engine_skin[joint_ids.x * 4 + 0], engine_skin[joint_ids.x * 4 + 1], engine_skin[joint_ids.x * 4 + 2], engine_skin[joint_ids.x * 4 + 3]) * joint_weights.x;
    mat4 _133 = mat4(engine_skin[joint_ids.y * 4 + 0], engine_skin[joint_ids.y * 4 + 1], engine_skin[joint_ids.y * 4 + 2], engine_skin[joint_ids.y * 4 + 3]) * joint_weights.y;
    mat4 _154 = mat4(engine_skin[joint_ids.z * 4 + 0], engine_skin[joint_ids.z * 4 + 1], engine_skin[joint_ids.z * 4 + 2], engine_skin[joint_ids.z * 4 + 3]) * joint_weights.z;
    mat4 _175 = mat4(engine_skin[joint_ids.w * 4 + 0], engine_skin[joint_ids.w * 4 + 1], engine_skin[joint_ids.w * 4 + 2], engine_skin[joint_ids.w * 4 + 3]) * joint_weights.w;
    mat4 _188 = mat4(((_125[0] + _133[0]) + _154[0]) + _175[0], ((_125[1] + _133[1]) + _154[1]) + _175[1], ((_125[2] + _133[2]) + _154[2]) + _175[2], ((_125[3] + _133[3]) + _154[3]) + _175[3]);
    vec4 _199 = _188 * vec4(position, 1.0);
    vec4 _210 = _188 * vec4(normal, 0.0);
    Vertex param = Vertex(_199.xyz, _210.xyz, vec4((_188 * vec4(tangent.xyz, 0.0)).xyz, tangent.w), colour, uv, engine_vertex[12].x, engine_vertex[13], (_101 * vec4(_199.xyz, 1.0)).xyz, _101[3].xyz, transpose(mat3(_105[0].xyz, _105[1].xyz, _105[2].xyz)));
    rocco_vertex(param);
    vec4 _291 = vec4(param.position, 1.0);
    gl_Position = mat4(engine_vertex[0], engine_vertex[1], engine_vertex[2], engine_vertex[3]) * _291;
    v_col = param.colour;
    v_uv = param.uv;
    v_nrm = (_105 * vec4(param.normal, 0.0)).xyz;
    v_geometry = (_105 * vec4(_210.xyz, 0.0)).xyz;
    v_world = (_101 * _291).xyz;
    v_tng = vec4((_101 * vec4(param.tangent.xyz, 0.0)).xyz, param.tangent.w * ((determinant(mat3(_101[0].xyz, _101[1].xyz, _101[2].xyz)) < 0.0) ? (-1.0) : 1.0));
    v_time = engine_vertex[12].x;
    v_instance_tint = vec4(1.0);
    gl_Position.z = 2.0 * gl_Position.z - gl_Position.w;
}

