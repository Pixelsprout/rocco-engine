#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct Vertex
{
    float3 position;
    float3 normal;
    float4 tangent;
    float4 colour;
    float2 uv;
    float time;
    float4 draw;
    float3 world_position;
    float3 world_origin;
    float3x3 world_to_local_direction;
};

struct game_vertex
{
    float4 vertex_values[16];
};

struct engine_vertex
{
    float4x4 mvp;
    float4x4 model;
    float4x4 normal_model;
    float4 render_time;
    float4 draw_info;
    float4 camera;
    float4 reserved_vertex;
};

struct main0_out
{
    float4 v_col [[user(locn0)]];
    float3 v_nrm [[user(locn1)]];
    float3 v_geometry [[user(locn2)]];
    float3 v_world [[user(locn3)]];
    float2 v_uv [[user(locn4)]];
    float4 v_tng [[user(locn5)]];
    float v_time [[user(locn6)]];
    float4 v_instance_tint [[user(locn7)]];
    float4 gl_Position [[position]];
};

struct main0_in
{
    float3 position [[attribute(0)]];
    float4 colour [[attribute(1)]];
    float3 normal [[attribute(2)]];
    float2 uv [[attribute(3)]];
    float4 tangent [[attribute(4)]];
};

static inline __attribute__((always_inline))
float4 sample_weights(thread const float2& uv, texture2d<float> game_weights_tex, sampler game_weights_smp)
{
    return game_weights_tex.sample(game_weights_smp, uv, level(0.0));
}

static inline __attribute__((always_inline))
float param_phase(constant game_vertex& _32)
{
    return _32.vertex_values[1].x;
}

static inline __attribute__((always_inline))
float param_wind(constant game_vertex& _32)
{
    return _32.vertex_values[0].x;
}

static inline __attribute__((always_inline))
void rocco_vertex(thread Vertex& vertex0, constant game_vertex& _32, texture2d<float> game_weights_tex, sampler game_weights_smp)
{
    float2 param = vertex0.uv;
    vertex0.position.x += ((sin(((vertex0.time * 2.0) + vertex0.world_origin.x) + param_phase(_32)) * param_wind(_32)) * (vertex0.colour.x * sample_weights(param, game_weights_tex, game_weights_smp).x));
}

vertex main0_out main0(main0_in in [[stage_in]], constant engine_vertex& _98 [[buffer(0)]], constant game_vertex& _32 [[buffer(4)]], texture2d<float> game_weights_tex [[texture(0)]], sampler game_weights_smp [[sampler(8)]])
{
    main0_out out = {};
    Vertex param = Vertex{ in.position, in.normal, in.tangent, in.colour, in.uv, _98.render_time.x, _98.draw_info, (_98.model * float4(in.position, 1.0)).xyz, _98.model[3].xyz, transpose(float3x3(_98.normal_model[0].xyz, _98.normal_model[1].xyz, _98.normal_model[2].xyz)) };
    rocco_vertex(param, _32, game_weights_tex, game_weights_smp);
    float4 _182 = float4(param.position, 1.0);
    out.gl_Position = _98.mvp * _182;
    out.v_col = param.colour;
    out.v_uv = param.uv;
    out.v_nrm = (_98.normal_model * float4(param.normal, 0.0)).xyz;
    out.v_geometry = (_98.normal_model * float4(in.normal, 0.0)).xyz;
    out.v_world = (_98.model * _182).xyz;
    out.v_tng = float4((_98.model * float4(param.tangent.xyz, 0.0)).xyz, param.tangent.w * ((determinant(float3x3(_98.model[0].xyz, _98.model[1].xyz, _98.model[2].xyz)) < 0.0) ? (-1.0) : 1.0));
    out.v_time = _98.render_time.x;
    out.v_instance_tint = float4(1.0);
    return out;
}

