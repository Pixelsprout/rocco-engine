struct SurfaceInput
{
    float4 colour;
    float2 uv;
    float3 world;
    float3 geometric_normal;
    float time;
};

struct Surface
{
    float3 base_colour;
    float opacity;
    float occlusion;
    float metallic;
    float roughness;
    float3 emission;
    float3 normal;
    bool unlit;
};

struct Lighting
{
    float3 normal;
    float3 view;
    float3 direction;
    float3 radiance;
    float attenuation;
    float3 diffuse;
    float3 specular;
    float3 base_colour;
    float roughness;
    float metallic;
};

struct Cluster
{
    uint4 range;
};

struct LightIndices
{
    uint4 ids;
};

struct Point
{
    float4 pos;
    float4 color;
};

cbuffer game_fragment : register(b5)
{
    float4 _99_fragment_values[16] : packoffset(c0);
};

cbuffer fs_lights : register(b2)
{
    float4 _263_ambient : packoffset(c0);
    float4 _263_camera_pos : packoffset(c1);
    float4 _263_shadow : packoffset(c2);
    float4 _263_cascade_far : packoffset(c3);
    float4 _263_view_dir : packoffset(c4);
    float4 _263_fog_color : packoffset(c5);
    float4 _263_fog_ramp : packoffset(c6);
    row_major float4x4 _263_light_view_proj[4] : packoffset(c7);
    float4 _263_directional_pos[4] : packoffset(c23);
    float4 _263_directional_color[4] : packoffset(c27);
    float4 _263_cluster_grid : packoffset(c31);
};

cbuffer fs_params : register(b1)
{
    float4 _621_tint : packoffset(c0);
    float4 _621_material : packoffset(c1);
    float4 _621_emissive : packoffset(c2);
    float4 _621_glow : packoffset(c3);
    float4 _621_maps : packoffset(c4);
    float4 _621_environment_params : packoffset(c5);
};

ByteAddressBuffer _1032 : register(t9);
ByteAddressBuffer _1108 : register(t10);
ByteAddressBuffer _1126 : register(t8);
Texture2DArray<float4> shadow_tex : register(t2);
SamplerComparisonState shadow_smp : register(s2);
Texture2D<float4> normal_tex : register(t4);
SamplerState normal_smp : register(s4);
Texture2D<float4> base_tex : register(t0);
SamplerState base_smp : register(s0);
Texture2D<float4> metallic_roughness_tex : register(t1);
SamplerState metallic_roughness_smp : register(s1);
Texture2D<float4> emissive_tex : register(t3);
SamplerState emissive_smp : register(s3);
Texture2D<float4> occlusion_tex : register(t5);
SamplerState occlusion_smp : register(s5);
TextureCube<float4> env_diffuse_tex : register(t6);
SamplerState env_diffuse_smp : register(s6);
TextureCube<float4> env_specular_tex : register(t7);
SamplerState env_specular_smp : register(s7);

static float4 gl_FragCoord;
static bool gl_FrontFacing;
static float3 v_world;
static float3 v_nrm;
static float4 v_tng;
static float2 v_uv;
static float4 v_col;
static float3 v_geometry;
static float v_time;
static float4 v_instance_tint;
static float4 frag_colour;

struct SPIRV_Cross_Input
{
    float4 v_col : TEXCOORD0;
    float3 v_nrm : TEXCOORD1;
    float3 v_geometry : TEXCOORD2;
    float3 v_world : TEXCOORD3;
    float2 v_uv : TEXCOORD4;
    float4 v_tng : TEXCOORD5;
    nointerpolation float v_time : TEXCOORD6;
    float4 v_instance_tint : TEXCOORD7;
    float4 gl_FragCoord : SV_Position;
    bool gl_FrontFacing : SV_IsFrontFace;
};

struct SPIRV_Cross_Output
{
    float4 frag_colour : SV_Target0;
};

uint3 spvTextureSize(Texture2DArray<float4> Tex, uint Level, out uint Param)
{
    uint3 ret;
    Tex.GetDimensions(Level, ret.x, ret.y, ret.z, Param);
    return ret;
}

float3 safe_normalize(float3 v)
{
    return v / max(length(v), 9.9999999747524270787835121154785e-07f).xxx;
}

float sun_visibility_in(int cascade, float3 n)
{
    float4 _282 = mul(float4(v_world + (n * _263_shadow.z), 1.0f), _263_light_view_proj[cascade]);
    float3 _290 = _282.xyz / _282.w.xxx;
    float2 _296 = (_290.xy * 0.5f) + 0.5f.xx;
    _296.y = 1.0f - _296.y;
    bool _307 = all(bool2(_296.x >= 0.0f.xx.x, _296.y >= 0.0f.xx.y));
    bool _314;
    if (_307)
    {
        _314 = all(bool2(_296.x <= 1.0f.xx.x, _296.y <= 1.0f.xx.y));
    }
    else
    {
        _314 = _307;
    }
    uint _329_dummy_parameter;
    float2 _334 = 1.0f.xx / float2(int3(spvTextureSize(shadow_tex, uint(0), _329_dummy_parameter)).xy);
    float sum = 0.0f;
    int _340 = int(_263_fog_color.w);
    int _343 = -_340;
    for (int y = _343; y <= _340; y++)
    {
        for (int x = _343; x <= _340; x++)
        {
            float _382 = _290.z + _263_camera_pos.w;
            sum += shadow_tex.SampleCmp(shadow_smp, float4(_296 + (float2(float(x), float(y)) * _334), float(cascade), _382).xyz, _382);
        }
    }
    float _398 = float((_340 * 2) + 1);
    float _400;
    if (_314)
    {
        _400 = sum / (_398 * _398);
    }
    else
    {
        _400 = 1.0f;
    }
    return _400;
}

float4 cascade_mask(int cascade)
{
    int4 _414 = cascade.xxxx;
    return float4(bool4(_414.x == int4(0, 1, 2, 3).x, _414.y == int4(0, 1, 2, 3).y, _414.z == int4(0, 1, 2, 3).z, _414.w == int4(0, 1, 2, 3).w));
}

float sun_visibility(float3 n)
{
    int _427 = int(_263_shadow.x);
    bool _429 = _427 <= 1;
    bool _436;
    if (_429)
    {
        _436 = _263_view_dir.w == 0.0f;
    }
    else
    {
        _436 = _429;
    }
    if (_436)
    {
        int param = 0;
        float3 param_1 = n;
        return sun_visibility_in(param, param_1);
    }
    float _453 = dot(v_world - _263_camera_pos.xyz, _263_view_dir.xyz);
    float4 _456 = _453.xxxx;
    int _466 = _427 - 1;
    float4 _468 = float(_466).xxxx;
    int _475 = int(dot(float4(bool4(_456.x > _263_cascade_far.x, _456.y > _263_cascade_far.y, _456.z > _263_cascade_far.z, _456.w > _263_cascade_far.w)), float4(bool4(float4(0.0f, 1.0f, 2.0f, 3.0f).x < _468.x, float4(0.0f, 1.0f, 2.0f, 3.0f).y < _468.y, float4(0.0f, 1.0f, 2.0f, 3.0f).z < _468.z, float4(0.0f, 1.0f, 2.0f, 3.0f).w < _468.w))));
    int param_2 = _475;
    float _482 = dot(_263_cascade_far, cascade_mask(param_2));
    int param_3 = _475 - 1;
    float _499 = _482 - (_263_shadow.w * (_482 - dot(_263_cascade_far, cascade_mask(param_3))));
    float _504;
    if (_499 < _482)
    {
        _504 = smoothstep(_499, _482, _453);
    }
    else
    {
        _504 = step(_482, _453);
    }
    int _521 = min((_475 + 1), _466);
    int param_4 = _475;
    float3 param_5 = n;
    int param_6 = _521;
    float3 param_7 = n;
    return lerp(sun_visibility_in(param_4, param_5), (_521 == _475) ? 1.0f : sun_visibility_in(param_6, param_7), _504);
}

float3 surface_normal()
{
    float3 param = v_nrm;
    float3 _579 = safe_normalize(param);
    float3 param_1 = v_tng.xyz - (_579 * dot(_579, v_tng.xyz));
    float3 _593 = safe_normalize(param_1);
    float3 _618 = (normal_tex.Sample(normal_smp, v_uv).xyz * 2.0f) - 1.0f.xxx;
    float2 _626 = _618.xy * _621_maps.x;
    float3 param_2 = ((_593 * _626.x) + ((cross(_579, _593) * v_tng.w) * _626.y)) + (_579 * _618.z);
    return safe_normalize(param_2);
}

Surface imported_surface()
{
    float4 _683 = ((v_col * _621_tint) * v_instance_tint) * base_tex.Sample(base_smp, v_uv);
    float4 _698 = metallic_roughness_tex.Sample(metallic_roughness_smp, v_uv);
    Surface _1312 = { _683.xyz, _683.w, lerp(1.0f, occlusion_tex.Sample(occlusion_smp, v_uv).x, _621_maps.y), _621_material.y * _698.z, _621_material.x * _698.y, (_621_emissive.xyz * emissive_tex.Sample(emissive_smp, v_uv).xyz) + _621_glow.xyz, surface_normal(), _621_material.z != 0.0f };
    return _1312;
}

SurfaceInput surface_input()
{
    float3 param = v_geometry;
    SurfaceInput _1295 = { v_col, v_uv, v_world, safe_normalize(param), v_time };
    return _1295;
}

float4 param_leaf_tint()
{
    return _99_fragment_values[0];
}

void rocco_surface(inout Surface surface, SurfaceInput data)
{
    surface.base_colour *= param_leaf_tint().xyz;
}

float3 apply_fog(float3 color, float coverage)
{
    return lerp(color, _263_fog_color.xyz * coverage, (_263_fog_ramp.z * clamp((length(v_world - _263_camera_pos.xyz) - _263_fog_ramp.x) * _263_fog_ramp.y, 0.0f, 1.0f)).xxx);
}

float3 env_brdf_approx(float3 f0, float roughness, float n_dot_v)
{
    float4 _212 = (float4(-1.0f, -0.0274999998509883880615234375f, -0.572000026702880859375f, 0.02199999988079071044921875f) * roughness) + float4(1.0f, 0.0425000004470348358154296875f, 1.03999996185302734375f, -0.039999999105930328369140625f);
    float _216 = _212.x;
    float2 _240 = (float2(-1.03999996185302734375f, 1.03999996185302734375f) * ((min(_216 * _216, exp2((-9.27999973297119140625f) * n_dot_v)) * _216) + _212.y)) + _212.zw;
    return (f0 * _240.x) + _240.y.xxx;
}

float pow5(float x)
{
    float _118 = x * x;
    return (_118 * _118) * x;
}

float3 fresnel_schlick(float3 f0, float v_dot_h)
{
    float param = 1.0f - v_dot_h;
    return f0 + ((1.0f.xxx - f0) * pow5(param));
}

float distribution_ggx(float n_dot_h, float alpha)
{
    float _129 = alpha * alpha;
    float _139 = (((n_dot_h * _129) - n_dot_h) * n_dot_h) + 1.0f;
    return _129 / max((3.1415927410125732421875f * _139) * _139, 9.9999999600419720025001879548654e-13f);
}

float visibility_smith(float n_dot_v, float n_dot_l, float alpha)
{
    float _154 = alpha * alpha;
    float _161 = 1.0f - _154;
    return 0.5f / max((n_dot_l * sqrt(((n_dot_v * n_dot_v) * _161) + _154)) + (n_dot_v * sqrt(((n_dot_l * n_dot_l) * _161) + _154)), 9.9999999747524270787835121154785e-07f);
}

float3 rocco_lighting(Lighting data)
{
    return ((data.diffuse + data.specular) * data.radiance) * (clamp(dot(data.normal, data.direction), 0.0f, 1.0f) * data.attenuation);
}

float4 surface_color(bool premultiplied)
{
    float _781 = gl_FrontFacing ? 1.0f : (-1.0f);
    float sun_attenuation = 1.0f;
    bool _785 = _263_shadow.x > 0.0f;
    if (_785)
    {
        float3 param = v_geometry;
        float3 param_1 = safe_normalize(param) * _781;
        sun_attenuation = sun_visibility(param_1);
    }
    Surface _796 = imported_surface();
    float3 _1313 = _796.base_colour;
    float _1314 = _796.opacity;
    float _1315 = _796.occlusion;
    float _1316 = _796.metallic;
    float _1317 = _796.roughness;
    float3 _1318 = _796.emission;
    float3 _1319 = _796.normal;
    bool _1320 = _796.unlit;
    Surface _1337 = { _1313, _1314, _1315, _1316, _1317, _1318, _1319, _1320 };
    Surface param_2 = _1337;
    SurfaceInput param_3 = surface_input();
    rocco_surface(param_2, param_3);
    _1313 = param_2.base_colour;
    _1314 = param_2.opacity;
    _1315 = param_2.occlusion;
    _1316 = param_2.metallic;
    _1317 = param_2.roughness;
    _1318 = param_2.emission;
    _1319 = param_2.normal;
    _1320 = param_2.unlit;
    float _814;
    if (premultiplied)
    {
        _814 = param_2.opacity;
    }
    else
    {
        _814 = 1.0f;
    }
    float3 _823 = float4(param_2.base_colour, param_2.opacity).xyz;
    if (_1320)
    {
        float3 param_4 = (_823 * _814) + _1318;
        float param_5 = _814;
        return float4(apply_fog(param_4, param_5), param_2.opacity);
    }
    float _851 = clamp(_1317, 0.04500000178813934326171875f, 1.0f);
    float _855 = clamp(_1316, 0.0f, 1.0f);
    float _859 = _851 * _851;
    float3 _866 = lerp(0.039999999105930328369140625f.xxx, _823, _855.xxx);
    float3 _873 = (_823 * (1.0f - _855)) * _814;
    float3 param_6 = _1319;
    float3 _880 = safe_normalize(param_6) * _781;
    float3 param_7 = _263_camera_pos.xyz - v_world;
    float3 _888 = safe_normalize(param_7);
    float _892 = dot(_880, _888);
    float _894 = max(_892, 9.9999997473787516355514526367188e-05f);
    float _900 = max(abs(_892), 9.9999997473787516355514526367188e-05f);
    float3 param_8 = _866;
    float param_9 = _851;
    float param_10 = _900;
    float3 color = (_263_ambient.xyz * (_873 + env_brdf_approx(param_8, param_9, param_10))) * _1315;
    if (_621_environment_params.x > 0.0f)
    {
        float3 param_11 = _866;
        float param_12 = _900;
        float3 param_13 = _866;
        float param_14 = _851;
        float param_15 = _900;
        color += (((((1.0f.xxx - fresnel_schlick(param_11, param_12)) * _873) * env_diffuse_tex.SampleLevel(env_diffuse_smp, _880, 0.0f).xyz) + (env_brdf_approx(param_13, param_14, param_15) * env_specular_tex.SampleLevel(env_specular_smp, reflect(-_888, _880), _851 * _621_environment_params.y).xyz)) * _1315);
    }
    float2 _985 = gl_FragCoord.xy * _263_cluster_grid.xy;
    _985.y = 9.0f - _985.y;
    int2 _999 = clamp(int2(_985), int2(0, 0), int2(15, 8));
    int _1043 = (((clamp(int(log(max(dot(v_world - _263_camera_pos.xyz, _263_view_dir.xyz), _263_cluster_grid.w) / _263_cluster_grid.w) * _263_cluster_grid.z), 0, 23) * 9) + _999.y) * 16) + _999.x;
    int _1050 = int(_263_ambient.w);
    int _1057 = _1050 + int(_1032.Load4(_1043 * 16 + 0).y);
    float3 l;
    float3 radiance;
    for (int i = 0; i < _1057; i++)
    {
        float attenuation = 1.0f;
        if (i < _1050)
        {
            l = _263_directional_pos[i].xyz;
            radiance = _263_directional_color[i].xyz;
            bool _1084 = i == 0;
            bool _1090;
            if (_1084)
            {
                _1090 = _785;
            }
            else
            {
                _1090 = _1084;
            }
            if (_1090)
            {
                attenuation = sun_attenuation;
            }
        }
        else
        {
            uint _1102 = _1032.Load4(_1043 * 16 + 0).x + uint(i - _1050);
            uint4 ids = _1108.Load4((_1102 / 4u) * 16 + 0);
            Point _1130;
            _1130.pos = asfloat(_1126.Load4(ids[int(_1102 % 4u)] * 32 + 0));
            _1130.color = asfloat(_1126.Load4(ids[int(_1102 % 4u)] * 32 + 16));
            float3 _1140 = _1130.pos.xyz - v_world;
            float _1144 = dot(_1140, _1140);
            float _1155 = clamp(1.0f - (_1144 / (_1130.color.w * _1130.color.w)), 0.0f, 1.0f);
            attenuation = (_1155 * _1155) / max(_1144, 9.9999997473787516355514526367188e-05f);
            float3 param_16 = _1140;
            l = safe_normalize(param_16);
            radiance = _1130.color.xyz;
        }
        float3 param_17 = l + _888;
        float3 _1178 = safe_normalize(param_17);
        float3 param_18 = _866;
        float param_19 = clamp(dot(_888, _1178), 0.0f, 1.0f);
        float3 _1194 = fresnel_schlick(param_18, param_19);
        float param_20 = clamp(dot(_880, _1178), 0.0f, 1.0f);
        float param_21 = _859;
        float param_22 = _894;
        float param_23 = clamp(dot(_880, l), 0.0f, 1.0f);
        float param_24 = _859;
        Lighting _1369 = { _880, _888, l, radiance, attenuation, ((1.0f.xxx - _1194) * _873) * 0.3183098733425140380859375f.xxx, _1194 * (distribution_ggx(param_20, param_21) * visibility_smith(param_22, param_23, param_24)), _823, _851, _855 };
        Lighting param_25 = _1369;
        color += rocco_lighting(param_25);
    }
    float3 param_26 = color + _1318;
    float param_27 = _814;
    return float4(apply_fog(param_26, param_27), param_2.opacity);
}

void frag_main()
{
    bool param = _621_maps.z == 2.0f;
    float4 _1267 = surface_color(param);
    bool _1270 = _621_maps.z == 1.0f;
    bool _1278;
    if (_1270)
    {
        _1278 = _1267.w < _621_material.w;
    }
    else
    {
        _1278 = _1270;
    }
    if (_1278)
    {
        discard;
    }
    frag_colour = _1267;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    gl_FragCoord = stage_input.gl_FragCoord;
    gl_FragCoord.w = 1.0 / gl_FragCoord.w;
    gl_FrontFacing = stage_input.gl_FrontFacing;
    v_world = stage_input.v_world;
    v_nrm = stage_input.v_nrm;
    v_tng = stage_input.v_tng;
    v_uv = stage_input.v_uv;
    v_col = stage_input.v_col;
    v_geometry = stage_input.v_geometry;
    v_time = stage_input.v_time;
    v_instance_tint = stage_input.v_instance_tint;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.frag_colour = frag_colour;
    return stage_output;
}
