#version 430

struct PostInput
{
    vec2 uv;
    vec2 pixel_size;
    float time;
};

uniform vec4 game_fragment[16];
uniform vec4 engine_post[8];
layout(binding = 0) uniform sampler2D scene_depth_scene_depth_smp;
layout(binding = 1) uniform sampler2D selection_coverage_selection_coverage_smp;
layout(binding = 2) uniform sampler2D selection_depth_selection_depth_smp;
layout(binding = 3) uniform sampler2D scene_colour_scene_colour_smp;

layout(location = 0) in vec2 v_uv;
layout(location = 0) out vec4 frag_colour;

vec4 sample_scene_depth(vec2 uv)
{
    return texture(scene_depth_scene_depth_smp, uv);
}

vec4 sample_selection_coverage(vec2 uv)
{
    return texture(selection_coverage_selection_coverage_smp, uv);
}

vec4 sample_selection_depth(vec2 uv)
{
    return texture(selection_depth_selection_depth_smp, uv);
}

float param_mode()
{
    return game_fragment[0].x;
}

vec4 sample_scene_colour(vec2 uv)
{
    return texture(scene_colour_scene_colour_smp, uv);
}

vec4 rocco_post(PostInput data)
{
    vec2 param = data.uv;
    vec4 _92 = sample_scene_depth(param);
    float _93 = _92.x;
    vec2 param_1 = data.uv;
    vec4 _98 = sample_selection_coverage(param_1);
    float _99 = _98.x;
    vec2 param_2 = data.uv;
    vec4 _104 = sample_selection_depth(param_2);
    float _105 = _104.x;
    if (param_mode() < 0.5)
    {
        uint _115 = floatBitsToUint(_93);
        return vec4(float(_115 & 255u), float((_115 >> 8u) & 255u), float((_115 >> 16u) & 255u), float((_115 >> 24u) & 255u)) * vec4(0.0039215688593685626983642578125);
    }
    if (param_mode() < 1.5)
    {
        return vec4(float(_93 > 0.0), _99, float(_105 > 0.0), 1.0);
    }
    vec2 param_3 = data.uv;
    vec4 _161 = sample_scene_colour(param_3);
    bool _171 = _99 > 0.0;
    bool _179;
    if (_171)
    {
        _179 = _105 >= (_93 - ((param_mode() < 2.5) ? 9.9999997473787516355514526367188e-05 : 0.0));
    }
    else
    {
        _179 = _171;
    }
    return vec4((_161.xyz * 0.699999988079071044921875) + vec3(float(_179) * 0.20000000298023223876953125, _93 * 2.0, _99 * 0.100000001490116119384765625), 1.0);
}

void main()
{
    PostInput param = PostInput(v_uv, engine_post[0].zw, engine_post[1].x);
    frag_colour = rocco_post(param);
}

