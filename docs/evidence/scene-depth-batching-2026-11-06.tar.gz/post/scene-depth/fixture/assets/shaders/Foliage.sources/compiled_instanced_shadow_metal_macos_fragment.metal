#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct SurfaceInput
{
    float4 colour;
    float2 uv;
    float3 world;
    float3 geometric_normal;
    float time;
};

struct Surface
{
    float3 base_colour;
    float opacity;
    float occlusion;
    float metallic;
    float roughness;
    float3 emission;
    float3 normal;
    short unlit;
};

struct game_fragment
{
    float4 fragment_values[16];
};

struct fs_params
{
    float4 tint;
    float4 material;
    float4 emissive;
    float4 glow;
    float4 maps;
    float4 environment_params;
};

struct main0_in
{
    float4 v_col [[user(locn0)]];
    float3 v_nrm [[user(locn1)]];
    float3 v_geometry [[user(locn2)]];
    float3 v_world [[user(locn3)]];
    float2 v_uv [[user(locn4)]];
    float4 v_tng [[user(locn5)]];
    float v_time [[user(locn6), flat]];
    float4 v_instance_tint [[user(locn7)]];
};

static inline __attribute__((always_inline))
float3 safe_normalize(thread const float3& v)
{
    return v / float3(fast::max(length(v), 9.9999999747524270787835121154785e-07));
}

static inline __attribute__((always_inline))
float3 surface_normal(thread float3& v_nrm, thread float4& v_tng, texture2d<float> normal_tex, sampler normal_smp, thread float2& v_uv, constant fs_params& _114)
{
    float3 param = v_nrm;
    float3 _67 = safe_normalize(param);
    float3 param_1 = v_tng.xyz - (_67 * dot(_67, v_tng.xyz));
    float3 _81 = safe_normalize(param_1);
    float3 _111 = (normal_tex.sample(normal_smp, v_uv).xyz * 2.0) - float3(1.0);
    float2 _122 = _111.xy * _114.maps.x;
    float3 param_2 = ((_81 * _122.x) + ((cross(_67, _81) * v_tng.w) * _122.y)) + (_67 * _111.z);
    return safe_normalize(param_2);
}

static inline __attribute__((always_inline))
Surface imported_surface(thread float3& v_nrm, thread float4& v_tng, texture2d<float> normal_tex, sampler normal_smp, thread float2& v_uv, constant fs_params& _114, thread float4& v_col, thread float4& v_instance_tint, texture2d<float> base_tex, sampler base_smp, texture2d<float> metallic_roughness_tex, sampler metallic_roughness_smp, texture2d<float> emissive_tex, sampler emissive_smp, texture2d<float> occlusion_tex, sampler occlusion_smp)
{
    float4 _188 = ((v_col * _114.tint) * v_instance_tint) * base_tex.sample(base_smp, v_uv);
    float4 _203 = metallic_roughness_tex.sample(metallic_roughness_smp, v_uv);
    return Surface{ _188.xyz, _188.w, mix(1.0, occlusion_tex.sample(occlusion_smp, v_uv).x, _114.maps.y), _114.material.y * _203.z, _114.material.x * _203.y, (_114.emissive.xyz * emissive_tex.sample(emissive_smp, v_uv).xyz) + _114.glow.xyz, surface_normal(v_nrm, v_tng, normal_tex, normal_smp, v_uv, _114), short(_114.material.z != 0.0) };
}

static inline __attribute__((always_inline))
SurfaceInput surface_input(thread float2& v_uv, thread float4& v_col, thread float3& v_world, thread float3& v_geometry, thread float& v_time)
{
    float3 param = v_geometry;
    return SurfaceInput{ v_col, v_uv, v_world, safe_normalize(param), v_time };
}

static inline __attribute__((always_inline))
float4 param_leaf_tint(constant game_fragment& _45)
{
    return _45.fragment_values[0];
}

static inline __attribute__((always_inline))
void rocco_surface(thread Surface& surface, thread const SurfaceInput& data, constant game_fragment& _45)
{
    surface.base_colour *= param_leaf_tint(_45).xyz;
}

static inline __attribute__((always_inline))
float surface_coverage(constant game_fragment& _45, thread float3& v_nrm, thread float4& v_tng, texture2d<float> normal_tex, sampler normal_smp, thread float2& v_uv, constant fs_params& _114, thread float4& v_col, thread float3& v_world, thread float3& v_geometry, thread float& v_time, thread float4& v_instance_tint, texture2d<float> base_tex, sampler base_smp, texture2d<float> metallic_roughness_tex, sampler metallic_roughness_smp, texture2d<float> emissive_tex, sampler emissive_smp, texture2d<float> occlusion_tex, sampler occlusion_smp)
{
    Surface _268 = imported_surface(v_nrm, v_tng, normal_tex, normal_smp, v_uv, _114, v_col, v_instance_tint, base_tex, base_smp, metallic_roughness_tex, metallic_roughness_smp, emissive_tex, emissive_smp, occlusion_tex, occlusion_smp);
    float3 _359 = _268.base_colour;
    float _360 = _268.opacity;
    float _361 = _268.occlusion;
    float _362 = _268.metallic;
    float _363 = _268.roughness;
    float3 _364 = _268.emission;
    float3 _365 = _268.normal;
    bool _366 = _268.unlit;
    Surface param = Surface{ _359, _360, _361, _362, _363, _364, _365, short(_366) };
    SurfaceInput param_1 = surface_input(v_uv, v_col, v_world, v_geometry, v_time);
    rocco_surface(param, param_1, _45);
    _359 = param.base_colour;
    _360 = param.opacity;
    _361 = param.occlusion;
    _362 = param.metallic;
    _363 = param.roughness;
    _364 = param.emission;
    _365 = param.normal;
    _366 = param.unlit;
    return param.opacity;
}

fragment void main0(main0_in in [[stage_in]], constant fs_params& _114 [[buffer(1)]], constant game_fragment& _45 [[buffer(5)]], texture2d<float> base_tex [[texture(0)]], texture2d<float> metallic_roughness_tex [[texture(1)]], texture2d<float> emissive_tex [[texture(2)]], texture2d<float> normal_tex [[texture(3)]], texture2d<float> occlusion_tex [[texture(4)]], sampler base_smp [[sampler(0)]], sampler metallic_roughness_smp [[sampler(1)]], sampler emissive_smp [[sampler(3)]], sampler normal_smp [[sampler(4)]], sampler occlusion_smp [[sampler(5)]])
{
    float _280 = surface_coverage(_45, in.v_nrm, in.v_tng, normal_tex, normal_smp, in.v_uv, _114, in.v_col, in.v_world, in.v_geometry, in.v_time, in.v_instance_tint, base_tex, base_smp, metallic_roughness_tex, metallic_roughness_smp, emissive_tex, emissive_smp, occlusion_tex, occlusion_smp);
    bool _283 = _114.maps.z == 1.0;
    bool _290;
    if (_283)
    {
        _290 = _280 < _114.material.w;
    }
    else
    {
        _290 = _283;
    }
    if (_290)
    {
        discard_fragment();
    }
}

