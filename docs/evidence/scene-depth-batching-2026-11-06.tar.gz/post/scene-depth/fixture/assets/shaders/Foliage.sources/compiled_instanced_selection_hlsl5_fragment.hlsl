struct SurfaceInput
{
    float4 colour;
    float2 uv;
    float3 world;
    float3 geometric_normal;
    float time;
};

struct Surface
{
    float3 base_colour;
    float opacity;
    float occlusion;
    float metallic;
    float roughness;
    float3 emission;
    float3 normal;
    bool unlit;
};

cbuffer game_fragment : register(b5)
{
    float4 _45_fragment_values[16] : packoffset(c0);
};

cbuffer fs_params : register(b1)
{
    float4 _114_tint : packoffset(c0);
    float4 _114_material : packoffset(c1);
    float4 _114_emissive : packoffset(c2);
    float4 _114_glow : packoffset(c3);
    float4 _114_maps : packoffset(c4);
    float4 _114_environment_params : packoffset(c5);
};

Texture2D<float4> normal_tex : register(t3);
SamplerState normal_smp : register(s4);
Texture2D<float4> base_tex : register(t0);
SamplerState base_smp : register(s0);
Texture2D<float4> metallic_roughness_tex : register(t1);
SamplerState metallic_roughness_smp : register(s1);
Texture2D<float4> emissive_tex : register(t2);
SamplerState emissive_smp : register(s3);
Texture2D<float4> occlusion_tex : register(t4);
SamplerState occlusion_smp : register(s5);

static float4 gl_FragCoord;
static float3 v_nrm;
static float4 v_tng;
static float2 v_uv;
static float4 v_col;
static float3 v_world;
static float3 v_geometry;
static float v_time;
static float4 v_instance_tint;
static float selected_coverage;
static float selected_depth;

struct SPIRV_Cross_Input
{
    float4 v_col : TEXCOORD0;
    float3 v_nrm : TEXCOORD1;
    float3 v_geometry : TEXCOORD2;
    float3 v_world : TEXCOORD3;
    float2 v_uv : TEXCOORD4;
    float4 v_tng : TEXCOORD5;
    nointerpolation float v_time : TEXCOORD6;
    float4 v_instance_tint : TEXCOORD7;
    float4 gl_FragCoord : SV_Position;
};

struct SPIRV_Cross_Output
{
    float selected_coverage : SV_Target0;
    float selected_depth : SV_Target1;
};

float3 safe_normalize(float3 v)
{
    return v / max(length(v), 9.9999999747524270787835121154785e-07f).xxx;
}

float3 surface_normal()
{
    float3 param = v_nrm;
    float3 _67 = safe_normalize(param);
    float3 param_1 = v_tng.xyz - (_67 * dot(_67, v_tng.xyz));
    float3 _81 = safe_normalize(param_1);
    float3 _111 = (normal_tex.Sample(normal_smp, v_uv).xyz * 2.0f) - 1.0f.xxx;
    float2 _122 = _111.xy * _114_maps.x;
    float3 param_2 = ((_81 * _122.x) + ((cross(_67, _81) * v_tng.w) * _122.y)) + (_67 * _111.z);
    return safe_normalize(param_2);
}

Surface imported_surface()
{
    float4 _188 = ((v_col * _114_tint) * v_instance_tint) * base_tex.Sample(base_smp, v_uv);
    float4 _203 = metallic_roughness_tex.Sample(metallic_roughness_smp, v_uv);
    Surface _364 = { _188.xyz, _188.w, lerp(1.0f, occlusion_tex.Sample(occlusion_smp, v_uv).x, _114_maps.y), _114_material.y * _203.z, _114_material.x * _203.y, (_114_emissive.xyz * emissive_tex.Sample(emissive_smp, v_uv).xyz) + _114_glow.xyz, surface_normal(), _114_material.z != 0.0f };
    return _364;
}

SurfaceInput surface_input()
{
    float3 param = v_geometry;
    SurfaceInput _347 = { v_col, v_uv, v_world, safe_normalize(param), v_time };
    return _347;
}

float4 param_leaf_tint()
{
    return _45_fragment_values[0];
}

void rocco_surface(inout Surface surface, SurfaceInput data)
{
    surface.base_colour *= param_leaf_tint().xyz;
}

float surface_coverage()
{
    Surface _268 = imported_surface();
    float3 _365 = _268.base_colour;
    float _366 = _268.opacity;
    float _367 = _268.occlusion;
    float _368 = _268.metallic;
    float _369 = _268.roughness;
    float3 _370 = _268.emission;
    float3 _371 = _268.normal;
    bool _372 = _268.unlit;
    Surface _389 = { _365, _366, _367, _368, _369, _370, _371, _372 };
    Surface param = _389;
    SurfaceInput param_1 = surface_input();
    rocco_surface(param, param_1);
    _365 = param.base_colour;
    _366 = param.opacity;
    _367 = param.occlusion;
    _368 = param.metallic;
    _369 = param.roughness;
    _370 = param.emission;
    _371 = param.normal;
    _372 = param.unlit;
    return param.opacity;
}

void frag_main()
{
    float _280 = surface_coverage();
    bool _283 = _114_maps.z == 1.0f;
    bool _290;
    if (_283)
    {
        _290 = _280 < _114_material.w;
    }
    else
    {
        _290 = _283;
    }
    if (_290)
    {
        discard;
    }
    selected_coverage = 1.0f;
    selected_depth = gl_FragCoord.z;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    gl_FragCoord = stage_input.gl_FragCoord;
    gl_FragCoord.w = 1.0 / gl_FragCoord.w;
    v_nrm = stage_input.v_nrm;
    v_tng = stage_input.v_tng;
    v_uv = stage_input.v_uv;
    v_col = stage_input.v_col;
    v_world = stage_input.v_world;
    v_geometry = stage_input.v_geometry;
    v_time = stage_input.v_time;
    v_instance_tint = stage_input.v_instance_tint;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.selected_coverage = selected_coverage;
    stage_output.selected_depth = selected_depth;
    return stage_output;
}
