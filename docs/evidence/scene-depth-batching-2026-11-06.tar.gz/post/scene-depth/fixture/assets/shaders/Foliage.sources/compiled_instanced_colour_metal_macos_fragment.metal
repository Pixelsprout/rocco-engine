#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct SurfaceInput
{
    float4 colour;
    float2 uv;
    float3 world;
    float3 geometric_normal;
    float time;
};

struct Surface
{
    float3 base_colour;
    float opacity;
    float occlusion;
    float metallic;
    float roughness;
    float3 emission;
    float3 normal;
    short unlit;
};

struct Lighting
{
    float3 normal;
    float3 view;
    float3 direction;
    float3 radiance;
    float attenuation;
    float3 diffuse;
    float3 specular;
    float3 base_colour;
    float roughness;
    float metallic;
};

struct game_fragment
{
    float4 fragment_values[16];
};

struct fs_lights
{
    float4 ambient;
    float4 camera_pos;
    float4 shadow;
    float4 cascade_far;
    float4 view_dir;
    float4 fog_color;
    float4 fog_ramp;
    float4x4 light_view_proj[4];
    float4 directional_pos[4];
    float4 directional_color[4];
    float4 cluster_grid;
};

struct fs_params
{
    float4 tint;
    float4 material;
    float4 emissive;
    float4 glow;
    float4 maps;
    float4 environment_params;
};

struct Cluster
{
    uint4 range;
};

struct engine_clusters
{
    Cluster clusters[1];
};

struct LightIndices
{
    uint4 ids;
};

struct engine_indices
{
    LightIndices indices[1];
};

struct Point
{
    float4 pos;
    float4 color;
};

struct engine_points
{
    Point points[1];
};

struct main0_out
{
    float4 frag_colour [[color(0)]];
};

struct main0_in
{
    float4 v_col [[user(locn0)]];
    float3 v_nrm [[user(locn1)]];
    float3 v_geometry [[user(locn2)]];
    float3 v_world [[user(locn3)]];
    float2 v_uv [[user(locn4)]];
    float4 v_tng [[user(locn5)]];
    float v_time [[user(locn6), flat]];
    float4 v_instance_tint [[user(locn7)]];
};

static inline __attribute__((always_inline))
float3 safe_normalize(thread const float3& v)
{
    return v / float3(fast::max(length(v), 9.9999999747524270787835121154785e-07));
}

static inline __attribute__((always_inline))
float sun_visibility_in(thread const int& cascade, thread const float3& n, thread float3& v_world, constant fs_lights& _263, depth2d_array<float> shadow_tex, sampler shadow_smp)
{
    float4 _282 = _263.light_view_proj[cascade] * float4(v_world + (n * _263.shadow.z), 1.0);
    float3 _290 = _282.xyz / float3(_282.w);
    float2 _296 = (_290.xy * 0.5) + float2(0.5);
    _296.y = 1.0 - _296.y;
    bool _307 = all(_296 >= float2(0.0));
    bool _314;
    if (_307)
    {
        _314 = all(_296 <= float2(1.0));
    }
    else
    {
        _314 = _307;
    }
    float2 _334 = float2(1.0) / float2(int3(shadow_tex.get_width(), shadow_tex.get_height(), shadow_tex.get_array_size()).xy);
    float sum = 0.0;
    int _340 = int(_263.fog_color.w);
    int _343 = -_340;
    for (int y = _343; y <= _340; y++)
    {
        for (int x = _343; x <= _340; x++)
        {
            float _382 = _290.z + _263.camera_pos.w;
            float4 _385 = float4(_296 + (float2(float(x), float(y)) * _334), float(cascade), _382);
            sum += shadow_tex.sample_compare(shadow_smp, _385.xy, uint(rint(_385.z)), _382);
        }
    }
    float _398 = float((_340 * 2) + 1);
    float _400;
    if (_314)
    {
        _400 = sum / (_398 * _398);
    }
    else
    {
        _400 = 1.0;
    }
    return _400;
}

static inline __attribute__((always_inline))
float4 cascade_mask(thread const int& cascade)
{
    return float4(int4(cascade) == int4(0, 1, 2, 3));
}

static inline __attribute__((always_inline))
float sun_visibility(thread const float3& n, thread float3& v_world, constant fs_lights& _263, depth2d_array<float> shadow_tex, sampler shadow_smp)
{
    int _427 = int(_263.shadow.x);
    bool _429 = _427 <= 1;
    bool _436;
    if (_429)
    {
        _436 = _263.view_dir.w == 0.0;
    }
    else
    {
        _436 = _429;
    }
    if (_436)
    {
        int param = 0;
        float3 param_1 = n;
        return sun_visibility_in(param, param_1, v_world, _263, shadow_tex, shadow_smp);
    }
    float _453 = dot(v_world - _263.camera_pos.xyz, _263.view_dir.xyz);
    int _466 = _427 - 1;
    int _475 = int(dot(float4(float4(_453) > _263.cascade_far), float4(float4(0.0, 1.0, 2.0, 3.0) < float4(float(_466)))));
    int param_2 = _475;
    float _482 = dot(_263.cascade_far, cascade_mask(param_2));
    int param_3 = _475 - 1;
    float _499 = _482 - (_263.shadow.w * (_482 - dot(_263.cascade_far, cascade_mask(param_3))));
    float _504;
    if (_499 < _482)
    {
        _504 = smoothstep(_499, _482, _453);
    }
    else
    {
        _504 = step(_482, _453);
    }
    int _521 = min((_475 + 1), _466);
    int param_4 = _475;
    float3 param_5 = n;
    int param_6 = _521;
    float3 param_7 = n;
    return mix(sun_visibility_in(param_4, param_5, v_world, _263, shadow_tex, shadow_smp), (_521 == _475) ? 1.0 : sun_visibility_in(param_6, param_7, v_world, _263, shadow_tex, shadow_smp), _504);
}

static inline __attribute__((always_inline))
float3 surface_normal(thread float3& v_nrm, thread float4& v_tng, texture2d<float> normal_tex, sampler normal_smp, thread float2& v_uv, constant fs_params& _621)
{
    float3 param = v_nrm;
    float3 _579 = safe_normalize(param);
    float3 param_1 = v_tng.xyz - (_579 * dot(_579, v_tng.xyz));
    float3 _593 = safe_normalize(param_1);
    float3 _618 = (normal_tex.sample(normal_smp, v_uv).xyz * 2.0) - float3(1.0);
    float2 _626 = _618.xy * _621.maps.x;
    float3 param_2 = ((_593 * _626.x) + ((cross(_579, _593) * v_tng.w) * _626.y)) + (_579 * _618.z);
    return safe_normalize(param_2);
}

static inline __attribute__((always_inline))
Surface imported_surface(thread float3& v_nrm, thread float4& v_tng, texture2d<float> normal_tex, sampler normal_smp, thread float2& v_uv, constant fs_params& _621, thread float4& v_col, thread float4& v_instance_tint, texture2d<float> base_tex, sampler base_smp, texture2d<float> metallic_roughness_tex, sampler metallic_roughness_smp, texture2d<float> emissive_tex, sampler emissive_smp, texture2d<float> occlusion_tex, sampler occlusion_smp)
{
    float4 _683 = ((v_col * _621.tint) * v_instance_tint) * base_tex.sample(base_smp, v_uv);
    float4 _698 = metallic_roughness_tex.sample(metallic_roughness_smp, v_uv);
    return Surface{ _683.xyz, _683.w, mix(1.0, occlusion_tex.sample(occlusion_smp, v_uv).x, _621.maps.y), _621.material.y * _698.z, _621.material.x * _698.y, (_621.emissive.xyz * emissive_tex.sample(emissive_smp, v_uv).xyz) + _621.glow.xyz, surface_normal(v_nrm, v_tng, normal_tex, normal_smp, v_uv, _621), short(_621.material.z != 0.0) };
}

static inline __attribute__((always_inline))
SurfaceInput surface_input(thread float3& v_world, thread float2& v_uv, thread float4& v_col, thread float3& v_geometry, thread float& v_time)
{
    float3 param = v_geometry;
    return SurfaceInput{ v_col, v_uv, v_world, safe_normalize(param), v_time };
}

static inline __attribute__((always_inline))
float4 param_leaf_tint(constant game_fragment& _99)
{
    return _99.fragment_values[0];
}

static inline __attribute__((always_inline))
void rocco_surface(thread Surface& surface, thread const SurfaceInput& data, constant game_fragment& _99)
{
    surface.base_colour *= param_leaf_tint(_99).xyz;
}

static inline __attribute__((always_inline))
float3 apply_fog(thread const float3& color, thread const float& coverage, thread float3& v_world, constant fs_lights& _263)
{
    return mix(color, _263.fog_color.xyz * coverage, float3(_263.fog_ramp.z * fast::clamp((length(v_world - _263.camera_pos.xyz) - _263.fog_ramp.x) * _263.fog_ramp.y, 0.0, 1.0)));
}

static inline __attribute__((always_inline))
float3 env_brdf_approx(thread const float3& f0, thread const float& roughness, thread const float& n_dot_v)
{
    float4 _212 = (float4(-1.0, -0.0274999998509883880615234375, -0.572000026702880859375, 0.02199999988079071044921875) * roughness) + float4(1.0, 0.0425000004470348358154296875, 1.03999996185302734375, -0.039999999105930328369140625);
    float _216 = _212.x;
    float2 _240 = (float2(-1.03999996185302734375, 1.03999996185302734375) * ((fast::min(_216 * _216, exp2((-9.27999973297119140625) * n_dot_v)) * _216) + _212.y)) + _212.zw;
    return (f0 * _240.x) + float3(_240.y);
}

static inline __attribute__((always_inline))
float pow5(thread const float& x)
{
    float _118 = x * x;
    return (_118 * _118) * x;
}

static inline __attribute__((always_inline))
float3 fresnel_schlick(thread const float3& f0, thread const float& v_dot_h)
{
    float param = 1.0 - v_dot_h;
    return f0 + ((float3(1.0) - f0) * pow5(param));
}

static inline __attribute__((always_inline))
float distribution_ggx(thread const float& n_dot_h, thread const float& alpha)
{
    float _129 = alpha * alpha;
    float _139 = (((n_dot_h * _129) - n_dot_h) * n_dot_h) + 1.0;
    return _129 / fast::max((3.1415927410125732421875 * _139) * _139, 9.9999999600419720025001879548654e-13);
}

static inline __attribute__((always_inline))
float visibility_smith(thread const float& n_dot_v, thread const float& n_dot_l, thread const float& alpha)
{
    float _154 = alpha * alpha;
    float _161 = 1.0 - _154;
    return 0.5 / fast::max((n_dot_l * sqrt(((n_dot_v * n_dot_v) * _161) + _154)) + (n_dot_v * sqrt(((n_dot_l * n_dot_l) * _161) + _154)), 9.9999999747524270787835121154785e-07);
}

static inline __attribute__((always_inline))
float3 rocco_lighting(thread const Lighting& data)
{
    return ((data.diffuse + data.specular) * data.radiance) * (fast::clamp(dot(data.normal, data.direction), 0.0, 1.0) * data.attenuation);
}

static inline __attribute__((always_inline))
float4 surface_color(thread const bool& premultiplied, constant game_fragment& _99, thread float3& v_world, constant fs_lights& _263, depth2d_array<float> shadow_tex, sampler shadow_smp, thread float3& v_nrm, thread float4& v_tng, texture2d<float> normal_tex, sampler normal_smp, thread float2& v_uv, constant fs_params& _621, thread float4& v_col, thread float3& v_geometry, thread float& v_time, thread float4& v_instance_tint, texture2d<float> base_tex, sampler base_smp, texture2d<float> metallic_roughness_tex, sampler metallic_roughness_smp, texture2d<float> emissive_tex, sampler emissive_smp, texture2d<float> occlusion_tex, sampler occlusion_smp, thread bool& gl_FrontFacing, texturecube<float> env_diffuse_tex, sampler env_diffuse_smp, texturecube<float> env_specular_tex, sampler env_specular_smp, thread float4& gl_FragCoord, const device engine_clusters& _1032, const device engine_indices& _1108, const device engine_points& _1126)
{
    float _781 = gl_FrontFacing ? 1.0 : (-1.0);
    float sun_attenuation = 1.0;
    bool _785 = _263.shadow.x > 0.0;
    if (_785)
    {
        float3 param = v_geometry;
        float3 param_1 = safe_normalize(param) * _781;
        sun_attenuation = sun_visibility(param_1, v_world, _263, shadow_tex, shadow_smp);
    }
    Surface _796 = imported_surface(v_nrm, v_tng, normal_tex, normal_smp, v_uv, _621, v_col, v_instance_tint, base_tex, base_smp, metallic_roughness_tex, metallic_roughness_smp, emissive_tex, emissive_smp, occlusion_tex, occlusion_smp);
    float3 _1313 = _796.base_colour;
    float _1314 = _796.opacity;
    float _1315 = _796.occlusion;
    float _1316 = _796.metallic;
    float _1317 = _796.roughness;
    float3 _1318 = _796.emission;
    float3 _1319 = _796.normal;
    bool _1320 = _796.unlit;
    Surface param_2 = Surface{ _1313, _1314, _1315, _1316, _1317, _1318, _1319, short(_1320) };
    SurfaceInput param_3 = surface_input(v_world, v_uv, v_col, v_geometry, v_time);
    rocco_surface(param_2, param_3, _99);
    _1313 = param_2.base_colour;
    _1314 = param_2.opacity;
    _1315 = param_2.occlusion;
    _1316 = param_2.metallic;
    _1317 = param_2.roughness;
    _1318 = param_2.emission;
    _1319 = param_2.normal;
    _1320 = param_2.unlit;
    float _814;
    if (premultiplied)
    {
        _814 = param_2.opacity;
    }
    else
    {
        _814 = 1.0;
    }
    float3 _823 = float4(param_2.base_colour, param_2.opacity).xyz;
    if (_1320)
    {
        float3 param_4 = (_823 * _814) + _1318;
        float param_5 = _814;
        return float4(apply_fog(param_4, param_5, v_world, _263), param_2.opacity);
    }
    float _851 = fast::clamp(_1317, 0.04500000178813934326171875, 1.0);
    float _855 = fast::clamp(_1316, 0.0, 1.0);
    float _859 = _851 * _851;
    float3 _866 = mix(float3(0.039999999105930328369140625), _823, float3(_855));
    float3 _873 = (_823 * (1.0 - _855)) * _814;
    float3 param_6 = _1319;
    float3 _880 = safe_normalize(param_6) * _781;
    float3 param_7 = _263.camera_pos.xyz - v_world;
    float3 _888 = safe_normalize(param_7);
    float _892 = dot(_880, _888);
    float _894 = fast::max(_892, 9.9999997473787516355514526367188e-05);
    float _900 = fast::max(abs(_892), 9.9999997473787516355514526367188e-05);
    float3 param_8 = _866;
    float param_9 = _851;
    float param_10 = _900;
    float3 color = (_263.ambient.xyz * (_873 + env_brdf_approx(param_8, param_9, param_10))) * _1315;
    if (_621.environment_params.x > 0.0)
    {
        float3 param_11 = _866;
        float param_12 = _900;
        float3 param_13 = _866;
        float param_14 = _851;
        float param_15 = _900;
        color += (((((float3(1.0) - fresnel_schlick(param_11, param_12)) * _873) * env_diffuse_tex.sample(env_diffuse_smp, _880, level(0.0)).xyz) + (env_brdf_approx(param_13, param_14, param_15) * env_specular_tex.sample(env_specular_smp, reflect(-_888, _880), level(_851 * _621.environment_params.y)).xyz)) * _1315);
    }
    float2 _985 = gl_FragCoord.xy * _263.cluster_grid.xy;
    _985.y = 9.0 - _985.y;
    int2 _999 = clamp(int2(_985), int2(0), int2(15, 8));
    int _1043 = (((clamp(int(log(fast::max(dot(v_world - _263.camera_pos.xyz, _263.view_dir.xyz), _263.cluster_grid.w) / _263.cluster_grid.w) * _263.cluster_grid.z), 0, 23) * 9) + _999.y) * 16) + _999.x;
    int _1050 = int(_263.ambient.w);
    int _1057 = _1050 + int(_1032.clusters[_1043].range.y);
    float3 l;
    float3 radiance;
    for (int i = 0; i < _1057; i++)
    {
        float attenuation = 1.0;
        if (i < _1050)
        {
            l = _263.directional_pos[i].xyz;
            radiance = _263.directional_color[i].xyz;
            bool _1084 = i == 0;
            bool _1090;
            if (_1084)
            {
                _1090 = _785;
            }
            else
            {
                _1090 = _1084;
            }
            if (_1090)
            {
                attenuation = sun_attenuation;
            }
        }
        else
        {
            uint _1102 = _1032.clusters[_1043].range.x + uint(i - _1050);
            uint4 ids = _1108.indices[_1102 / 4u].ids;
            int _1116 = int(_1102 % 4u);
            float3 _1140 = _1126.points[ids[_1116]].pos.xyz - v_world;
            float _1144 = dot(_1140, _1140);
            float _1155 = fast::clamp(1.0 - (_1144 / (_1126.points[ids[_1116]].color.w * _1126.points[ids[_1116]].color.w)), 0.0, 1.0);
            attenuation = (_1155 * _1155) / fast::max(_1144, 9.9999997473787516355514526367188e-05);
            float3 param_16 = _1140;
            l = safe_normalize(param_16);
            radiance = _1126.points[ids[_1116]].color.xyz;
        }
        float3 param_17 = l + _888;
        float3 _1178 = safe_normalize(param_17);
        float3 param_18 = _866;
        float param_19 = fast::clamp(dot(_888, _1178), 0.0, 1.0);
        float3 _1194 = fresnel_schlick(param_18, param_19);
        float param_20 = fast::clamp(dot(_880, _1178), 0.0, 1.0);
        float param_21 = _859;
        float param_22 = _894;
        float param_23 = fast::clamp(dot(_880, l), 0.0, 1.0);
        float param_24 = _859;
        Lighting param_25 = Lighting{ _880, _888, l, radiance, attenuation, ((float3(1.0) - _1194) * _873) * float3(0.3183098733425140380859375), _1194 * (distribution_ggx(param_20, param_21) * visibility_smith(param_22, param_23, param_24)), _823, _851, _855 };
        color += rocco_lighting(param_25);
    }
    float3 param_26 = color + _1318;
    float param_27 = _814;
    return float4(apply_fog(param_26, param_27, v_world, _263), param_2.opacity);
}

fragment main0_out main0(main0_in in [[stage_in]], constant fs_params& _621 [[buffer(1)]], constant fs_lights& _263 [[buffer(2)]], constant game_fragment& _99 [[buffer(5)]], const device engine_points& _1126 [[buffer(8)]], const device engine_clusters& _1032 [[buffer(9)]], const device engine_indices& _1108 [[buffer(10)]], texture2d<float> base_tex [[texture(0)]], texture2d<float> metallic_roughness_tex [[texture(1)]], depth2d_array<float> shadow_tex [[texture(2)]], texture2d<float> emissive_tex [[texture(3)]], texture2d<float> normal_tex [[texture(4)]], texture2d<float> occlusion_tex [[texture(5)]], texturecube<float> env_diffuse_tex [[texture(6)]], texturecube<float> env_specular_tex [[texture(7)]], sampler base_smp [[sampler(0)]], sampler metallic_roughness_smp [[sampler(1)]], sampler shadow_smp [[sampler(2)]], sampler emissive_smp [[sampler(3)]], sampler normal_smp [[sampler(4)]], sampler occlusion_smp [[sampler(5)]], sampler env_diffuse_smp [[sampler(6)]], sampler env_specular_smp [[sampler(7)]], bool gl_FrontFacing [[front_facing]], float4 gl_FragCoord [[position]])
{
    main0_out out = {};
    bool param = _621.maps.z == 2.0;
    float4 _1267 = surface_color(param, _99, in.v_world, _263, shadow_tex, shadow_smp, in.v_nrm, in.v_tng, normal_tex, normal_smp, in.v_uv, _621, in.v_col, in.v_geometry, in.v_time, in.v_instance_tint, base_tex, base_smp, metallic_roughness_tex, metallic_roughness_smp, emissive_tex, emissive_smp, occlusion_tex, occlusion_smp, gl_FrontFacing, env_diffuse_tex, env_diffuse_smp, env_specular_tex, env_specular_smp, gl_FragCoord, _1032, _1108, _1126);
    bool _1270 = _621.maps.z == 1.0;
    bool _1278;
    if (_1270)
    {
        _1278 = _1267.w < _621.material.w;
    }
    else
    {
        _1278 = _1270;
    }
    if (_1278)
    {
        discard_fragment();
    }
    out.frag_colour = _1267;
    return out;
}

