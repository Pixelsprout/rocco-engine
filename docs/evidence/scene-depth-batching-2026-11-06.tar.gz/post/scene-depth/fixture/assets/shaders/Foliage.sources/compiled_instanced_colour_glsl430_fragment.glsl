#version 430

struct SurfaceInput
{
    vec4 colour;
    vec2 uv;
    vec3 world;
    vec3 geometric_normal;
    float time;
};

struct Surface
{
    vec3 base_colour;
    float opacity;
    float occlusion;
    float metallic;
    float roughness;
    vec3 emission;
    vec3 normal;
    bool unlit;
};

struct Lighting
{
    vec3 normal;
    vec3 view;
    vec3 direction;
    vec3 radiance;
    float attenuation;
    vec3 diffuse;
    vec3 specular;
    vec3 base_colour;
    float roughness;
    float metallic;
};

struct Cluster
{
    uvec4 range;
};

struct LightIndices
{
    uvec4 ids;
};

struct Point
{
    vec4 pos;
    vec4 color;
};

uniform vec4 game_fragment[16];
uniform vec4 fs_lights[32];
uniform vec4 fs_params[6];
layout(binding = 13, std430) readonly buffer engine_clusters
{
    Cluster clusters[];
} _1023;

layout(binding = 14, std430) readonly buffer engine_indices
{
    LightIndices indices[];
} _1099;

layout(binding = 12, std430) readonly buffer engine_points
{
    Point points[];
} _1117;

layout(binding = 0) uniform sampler2DArrayShadow shadow_tex_shadow_smp;
layout(binding = 1) uniform sampler2D base_tex_base_smp;
layout(binding = 2) uniform sampler2D metallic_roughness_tex_metallic_roughness_smp;
layout(binding = 3) uniform sampler2D emissive_tex_emissive_smp;
layout(binding = 4) uniform sampler2D normal_tex_normal_smp;
layout(binding = 5) uniform sampler2D occlusion_tex_occlusion_smp;
layout(binding = 6) uniform samplerCube env_diffuse_tex_env_diffuse_smp;
layout(binding = 7) uniform samplerCube env_specular_tex_env_specular_smp;

layout(location = 3) in vec3 v_world;
layout(location = 1) in vec3 v_nrm;
layout(location = 5) in vec4 v_tng;
layout(location = 4) in vec2 v_uv;
layout(location = 0) in vec4 v_col;
layout(location = 2) in vec3 v_geometry;
layout(location = 6) flat in float v_time;
layout(location = 7) in vec4 v_instance_tint;
layout(location = 0) out vec4 frag_colour;

vec3 safe_normalize(vec3 v)
{
    return v / vec3(max(length(v), 9.9999999747524270787835121154785e-07));
}

float sun_visibility_in(int cascade, vec3 n)
{
    vec4 _282 = mat4(fs_lights[cascade * 4 + 7], fs_lights[cascade * 4 + 8], fs_lights[cascade * 4 + 9], fs_lights[cascade * 4 + 10]) * vec4(v_world + (n * fs_lights[2].z), 1.0);
    vec3 _290 = _282.xyz / vec3(_282.w);
    vec2 _296 = (_290.xy * 0.5) + vec2(0.5);
    bool _303 = all(greaterThanEqual(_296, vec2(0.0)));
    bool _310;
    if (_303)
    {
        _310 = all(lessThanEqual(_296, vec2(1.0)));
    }
    else
    {
        _310 = _303;
    }
    vec2 _330 = vec2(1.0) / vec2(textureSize(shadow_tex_shadow_smp, 0).xy);
    float sum = 0.0;
    int _336 = int(fs_lights[5].w);
    int _339 = -_336;
    for (int y = _339; y <= _336; y++)
    {
        for (int x = _339; x <= _336; x++)
        {
            float _378 = _290.z + fs_lights[1].w;
            sum += texture(shadow_tex_shadow_smp, vec4(vec4(_296 + (vec2(float(x), float(y)) * _330), float(cascade), _378).xyz, _378));
        }
    }
    float _394 = float((_336 * 2) + 1);
    float _396;
    if (_310)
    {
        _396 = sum / (_394 * _394);
    }
    else
    {
        _396 = 1.0;
    }
    return _396;
}

vec4 cascade_mask(int cascade)
{
    return vec4(equal(ivec4(cascade), ivec4(0, 1, 2, 3)));
}

float sun_visibility(vec3 n)
{
    int _423 = int(fs_lights[2].x);
    bool _425 = _423 <= 1;
    bool _432;
    if (_425)
    {
        _432 = fs_lights[4].w == 0.0;
    }
    else
    {
        _432 = _425;
    }
    if (_432)
    {
        int param = 0;
        vec3 param_1 = n;
        return sun_visibility_in(param, param_1);
    }
    float _449 = dot(v_world - fs_lights[1].xyz, fs_lights[4].xyz);
    int _462 = _423 - 1;
    int _471 = int(dot(vec4(greaterThan(vec4(_449), fs_lights[3])), vec4(lessThan(vec4(0.0, 1.0, 2.0, 3.0), vec4(float(_462))))));
    int param_2 = _471;
    float _478 = dot(fs_lights[3], cascade_mask(param_2));
    int param_3 = _471 - 1;
    float _495 = _478 - (fs_lights[2].w * (_478 - dot(fs_lights[3], cascade_mask(param_3))));
    float _500;
    if (_495 < _478)
    {
        _500 = smoothstep(_495, _478, _449);
    }
    else
    {
        _500 = step(_478, _449);
    }
    int _517 = min((_471 + 1), _462);
    int param_4 = _471;
    vec3 param_5 = n;
    int param_6 = _517;
    vec3 param_7 = n;
    return mix(sun_visibility_in(param_4, param_5), (_517 == _471) ? 1.0 : sun_visibility_in(param_6, param_7), _500);
}

vec3 surface_normal()
{
    vec3 param = v_nrm;
    vec3 _575 = safe_normalize(param);
    vec3 param_1 = v_tng.xyz - (_575 * dot(_575, v_tng.xyz));
    vec3 _589 = safe_normalize(param_1);
    vec3 _614 = (texture(normal_tex_normal_smp, v_uv).xyz * 2.0) - vec3(1.0);
    vec2 _622 = _614.xy * fs_params[4].x;
    vec3 param_2 = ((_589 * _622.x) + ((cross(_575, _589) * v_tng.w) * _622.y)) + (_575 * _614.z);
    return safe_normalize(param_2);
}

Surface imported_surface()
{
    vec4 _679 = ((v_col * fs_params[0]) * v_instance_tint) * texture(base_tex_base_smp, v_uv);
    vec4 _694 = texture(metallic_roughness_tex_metallic_roughness_smp, v_uv);
    return Surface(_679.xyz, _679.w, mix(1.0, texture(occlusion_tex_occlusion_smp, v_uv).x, fs_params[4].y), fs_params[1].y * _694.z, fs_params[1].x * _694.y, (fs_params[2].xyz * texture(emissive_tex_emissive_smp, v_uv).xyz) + fs_params[3].xyz, surface_normal(), fs_params[1].z != 0.0);
}

SurfaceInput surface_input()
{
    vec3 param = v_geometry;
    return SurfaceInput(v_col, v_uv, v_world, safe_normalize(param), v_time);
}

vec4 param_leaf_tint()
{
    return game_fragment[0];
}

void rocco_surface(inout Surface surface, SurfaceInput data)
{
    surface.base_colour *= param_leaf_tint().xyz;
}

vec3 apply_fog(vec3 color, float coverage)
{
    return mix(color, fs_lights[5].xyz * coverage, vec3(fs_lights[6].z * clamp((length(v_world - fs_lights[1].xyz) - fs_lights[6].x) * fs_lights[6].y, 0.0, 1.0)));
}

vec3 env_brdf_approx(vec3 f0, float roughness, float n_dot_v)
{
    vec4 _212 = (vec4(-1.0, -0.0274999998509883880615234375, -0.572000026702880859375, 0.02199999988079071044921875) * roughness) + vec4(1.0, 0.0425000004470348358154296875, 1.03999996185302734375, -0.039999999105930328369140625);
    float _216 = _212.x;
    vec2 _240 = (vec2(-1.03999996185302734375, 1.03999996185302734375) * ((min(_216 * _216, exp2((-9.27999973297119140625) * n_dot_v)) * _216) + _212.y)) + _212.zw;
    return (f0 * _240.x) + vec3(_240.y);
}

float pow5(float x)
{
    float _118 = x * x;
    return (_118 * _118) * x;
}

vec3 fresnel_schlick(vec3 f0, float v_dot_h)
{
    float param = 1.0 - v_dot_h;
    return f0 + ((vec3(1.0) - f0) * pow5(param));
}

float distribution_ggx(float n_dot_h, float alpha)
{
    float _129 = alpha * alpha;
    float _139 = (((n_dot_h * _129) - n_dot_h) * n_dot_h) + 1.0;
    return _129 / max((3.1415927410125732421875 * _139) * _139, 9.9999999600419720025001879548654e-13);
}

float visibility_smith(float n_dot_v, float n_dot_l, float alpha)
{
    float _154 = alpha * alpha;
    float _161 = 1.0 - _154;
    return 0.5 / max((n_dot_l * sqrt(((n_dot_v * n_dot_v) * _161) + _154)) + (n_dot_v * sqrt(((n_dot_l * n_dot_l) * _161) + _154)), 9.9999999747524270787835121154785e-07);
}

vec3 rocco_lighting(Lighting data)
{
    return ((data.diffuse + data.specular) * data.radiance) * (clamp(dot(data.normal, data.direction), 0.0, 1.0) * data.attenuation);
}

vec4 surface_color(bool premultiplied)
{
    float _777 = gl_FrontFacing ? 1.0 : (-1.0);
    float sun_attenuation = 1.0;
    bool _781 = fs_lights[2].x > 0.0;
    if (_781)
    {
        vec3 param = v_geometry;
        vec3 param_1 = safe_normalize(param) * _777;
        sun_attenuation = sun_visibility(param_1);
    }
    Surface _792 = imported_surface();
    vec3 _1304 = _792.base_colour;
    float _1305 = _792.opacity;
    float _1306 = _792.occlusion;
    float _1307 = _792.metallic;
    float _1308 = _792.roughness;
    vec3 _1309 = _792.emission;
    vec3 _1310 = _792.normal;
    bool _1311 = _792.unlit;
    Surface param_2 = Surface(_1304, _1305, _1306, _1307, _1308, _1309, _1310, _1311);
    SurfaceInput param_3 = surface_input();
    rocco_surface(param_2, param_3);
    _1304 = param_2.base_colour;
    _1305 = param_2.opacity;
    _1306 = param_2.occlusion;
    _1307 = param_2.metallic;
    _1308 = param_2.roughness;
    _1309 = param_2.emission;
    _1310 = param_2.normal;
    _1311 = param_2.unlit;
    float _810;
    if (premultiplied)
    {
        _810 = param_2.opacity;
    }
    else
    {
        _810 = 1.0;
    }
    vec3 _819 = vec4(param_2.base_colour, param_2.opacity).xyz;
    if (_1311)
    {
        vec3 param_4 = (_819 * _810) + _1309;
        float param_5 = _810;
        return vec4(apply_fog(param_4, param_5), param_2.opacity);
    }
    float _847 = clamp(_1308, 0.04500000178813934326171875, 1.0);
    float _851 = clamp(_1307, 0.0, 1.0);
    float _855 = _847 * _847;
    vec3 _862 = mix(vec3(0.039999999105930328369140625), _819, vec3(_851));
    vec3 _869 = (_819 * (1.0 - _851)) * _810;
    vec3 param_6 = _1310;
    vec3 _876 = safe_normalize(param_6) * _777;
    vec3 param_7 = fs_lights[1].xyz - v_world;
    vec3 _884 = safe_normalize(param_7);
    float _888 = dot(_876, _884);
    float _890 = max(_888, 9.9999997473787516355514526367188e-05);
    float _896 = max(abs(_888), 9.9999997473787516355514526367188e-05);
    vec3 param_8 = _862;
    float param_9 = _847;
    float param_10 = _896;
    vec3 color = (fs_lights[0].xyz * (_869 + env_brdf_approx(param_8, param_9, param_10))) * _1306;
    if (fs_params[5].x > 0.0)
    {
        vec3 param_11 = _862;
        float param_12 = _896;
        vec3 param_13 = _862;
        float param_14 = _847;
        float param_15 = _896;
        color += (((((vec3(1.0) - fresnel_schlick(param_11, param_12)) * _869) * textureLod(env_diffuse_tex_env_diffuse_smp, _876, 0.0).xyz) + (env_brdf_approx(param_13, param_14, param_15) * textureLod(env_specular_tex_env_specular_smp, reflect(-_884, _876), _847 * fs_params[5].y).xyz)) * _1306);
    }
    ivec2 _990 = clamp(ivec2(gl_FragCoord.xy * fs_lights[31].xy), ivec2(0), ivec2(15, 8));
    int _1034 = (((clamp(int(log(max(dot(v_world - fs_lights[1].xyz, fs_lights[4].xyz), fs_lights[31].w) / fs_lights[31].w) * fs_lights[31].z), 0, 23) * 9) + _990.y) * 16) + _990.x;
    int _1041 = int(fs_lights[0].w);
    int _1048 = _1041 + int(_1023.clusters[_1034].range.y);
    vec3 l;
    vec3 radiance;
    for (int i = 0; i < _1048; i++)
    {
        float attenuation = 1.0;
        if (i < _1041)
        {
            l = fs_lights[i * 1 + 23].xyz;
            radiance = fs_lights[i * 1 + 27].xyz;
            bool _1075 = i == 0;
            bool _1081;
            if (_1075)
            {
                _1081 = _781;
            }
            else
            {
                _1081 = _1075;
            }
            if (_1081)
            {
                attenuation = sun_attenuation;
            }
        }
        else
        {
            uint _1093 = _1023.clusters[_1034].range.x + uint(i - _1041);
            uvec4 ids = _1099.indices[_1093 / 4u].ids;
            int _1107 = int(_1093 % 4u);
            vec3 _1131 = _1117.points[ids[_1107]].pos.xyz - v_world;
            float _1135 = dot(_1131, _1131);
            float _1146 = clamp(1.0 - (_1135 / (_1117.points[ids[_1107]].color.w * _1117.points[ids[_1107]].color.w)), 0.0, 1.0);
            attenuation = (_1146 * _1146) / max(_1135, 9.9999997473787516355514526367188e-05);
            vec3 param_16 = _1131;
            l = safe_normalize(param_16);
            radiance = _1117.points[ids[_1107]].color.xyz;
        }
        vec3 param_17 = l + _884;
        vec3 _1169 = safe_normalize(param_17);
        vec3 param_18 = _862;
        float param_19 = clamp(dot(_884, _1169), 0.0, 1.0);
        vec3 _1185 = fresnel_schlick(param_18, param_19);
        float param_20 = clamp(dot(_876, _1169), 0.0, 1.0);
        float param_21 = _855;
        float param_22 = _890;
        float param_23 = clamp(dot(_876, l), 0.0, 1.0);
        float param_24 = _855;
        Lighting param_25 = Lighting(_876, _884, l, radiance, attenuation, ((vec3(1.0) - _1185) * _869) * vec3(0.3183098733425140380859375), _1185 * (distribution_ggx(param_20, param_21) * visibility_smith(param_22, param_23, param_24)), _819, _847, _851);
        color += rocco_lighting(param_25);
    }
    vec3 param_26 = color + _1309;
    float param_27 = _810;
    return vec4(apply_fog(param_26, param_27), param_2.opacity);
}

void main()
{
    bool param = fs_params[4].z == 2.0;
    vec4 _1258 = surface_color(param);
    bool _1261 = fs_params[4].z == 1.0;
    bool _1269;
    if (_1261)
    {
        _1269 = _1258.w < fs_params[1].w;
    }
    else
    {
        _1269 = _1261;
    }
    if (_1269)
    {
        discard;
    }
    frag_colour = _1258;
}

