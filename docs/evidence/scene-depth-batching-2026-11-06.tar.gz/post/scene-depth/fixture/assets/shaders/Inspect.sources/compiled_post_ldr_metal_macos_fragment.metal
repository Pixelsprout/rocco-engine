#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct PostInput
{
    float2 uv;
    float2 pixel_size;
    float time;
};

struct game_fragment
{
    float4 fragment_values[16];
};

struct engine_post
{
    float4 viewport;
    float4 frame;
    float4 reserved_post[6];
};

struct main0_out
{
    float4 frag_colour [[color(0)]];
};

struct main0_in
{
    float2 v_uv [[user(locn0)]];
};

static inline __attribute__((always_inline))
float4 sample_scene_depth(thread const float2& uv, texture2d<float> scene_depth, sampler scene_depth_smp)
{
    return scene_depth.sample(scene_depth_smp, uv);
}

static inline __attribute__((always_inline))
float4 sample_selection_coverage(thread const float2& uv, texture2d<float> selection_coverage, sampler selection_coverage_smp)
{
    return selection_coverage.sample(selection_coverage_smp, uv);
}

static inline __attribute__((always_inline))
float4 sample_selection_depth(thread const float2& uv, texture2d<float> selection_depth, sampler selection_depth_smp)
{
    return selection_depth.sample(selection_depth_smp, uv);
}

static inline __attribute__((always_inline))
float param_mode(constant game_fragment& _37)
{
    return _37.fragment_values[0].x;
}

static inline __attribute__((always_inline))
float4 sample_scene_colour(thread const float2& uv, texture2d<float> scene_colour, sampler scene_colour_smp)
{
    return scene_colour.sample(scene_colour_smp, uv);
}

static inline __attribute__((always_inline))
float4 rocco_post(thread const PostInput& data, constant game_fragment& _37, texture2d<float> scene_colour, sampler scene_colour_smp, texture2d<float> scene_depth, sampler scene_depth_smp, texture2d<float> selection_coverage, sampler selection_coverage_smp, texture2d<float> selection_depth, sampler selection_depth_smp)
{
    float2 param = data.uv;
    float4 _92 = sample_scene_depth(param, scene_depth, scene_depth_smp);
    float _93 = _92.x;
    float2 param_1 = data.uv;
    float4 _98 = sample_selection_coverage(param_1, selection_coverage, selection_coverage_smp);
    float _99 = _98.x;
    float2 param_2 = data.uv;
    float4 _104 = sample_selection_depth(param_2, selection_depth, selection_depth_smp);
    float _105 = _104.x;
    if (param_mode(_37) < 0.5)
    {
        uint _115 = as_type<uint>(_93);
        return float4(float(_115 & 255u), float((_115 >> 8u) & 255u), float((_115 >> 16u) & 255u), float((_115 >> 24u) & 255u)) * float4(0.0039215688593685626983642578125);
    }
    if (param_mode(_37) < 1.5)
    {
        return float4(float(_93 > 0.0), _99, float(_105 > 0.0), 1.0);
    }
    float2 param_3 = data.uv;
    float4 _161 = sample_scene_colour(param_3, scene_colour, scene_colour_smp);
    bool _171 = _99 > 0.0;
    bool _179;
    if (_171)
    {
        _179 = _105 >= (_93 - ((param_mode(_37) < 2.5) ? 9.9999997473787516355514526367188e-05 : 0.0));
    }
    else
    {
        _179 = _171;
    }
    return float4((_161.xyz * 0.699999988079071044921875) + float3(float(_179) * 0.20000000298023223876953125, _93 * 2.0, _99 * 0.100000001490116119384765625), 1.0);
}

fragment main0_out main0(main0_in in [[stage_in]], constant engine_post& _211 [[buffer(1)]], constant game_fragment& _37 [[buffer(5)]], texture2d<float> scene_colour [[texture(0)]], texture2d<float> scene_depth [[texture(1)]], texture2d<float> selection_coverage [[texture(2)]], texture2d<float> selection_depth [[texture(3)]], sampler scene_colour_smp [[sampler(0)]], sampler scene_depth_smp [[sampler(1)]], sampler selection_coverage_smp [[sampler(2)]], sampler selection_depth_smp [[sampler(3)]])
{
    main0_out out = {};
    PostInput param = PostInput{ in.v_uv, _211.viewport.zw, _211.frame.x };
    out.frag_colour = rocco_post(param, _37, scene_colour, scene_colour_smp, scene_depth, scene_depth_smp, selection_coverage, selection_coverage_smp, selection_depth, selection_depth_smp);
    return out;
}

