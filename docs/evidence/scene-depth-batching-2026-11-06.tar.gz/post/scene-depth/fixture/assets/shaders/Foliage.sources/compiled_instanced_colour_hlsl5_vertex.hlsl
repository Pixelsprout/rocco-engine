struct Vertex
{
    float3 position;
    float3 normal;
    float4 tangent;
    float4 colour;
    float2 uv;
    float time;
    float4 draw;
    float3 world_position;
    float3 world_origin;
    float3x3 world_to_local_direction;
};

cbuffer game_vertex : register(b4)
{
    float4 _32_vertex_values[16] : packoffset(c0);
};

cbuffer engine_vertex : register(b0)
{
    row_major float4x4 _194_mvp : packoffset(c0);
    row_major float4x4 _194_model : packoffset(c4);
    row_major float4x4 _194_normal_model : packoffset(c8);
    float4 _194_render_time : packoffset(c12);
    float4 _194_draw_info : packoffset(c13);
    float4 _194_camera : packoffset(c14);
    float4 _194_reserved_vertex : packoffset(c15);
};

Texture2D<float4> game_weights_tex : register(t0);
SamplerState game_weights_smp : register(s8);

static float4 gl_Position;
static float4 instance_model_0;
static float4 instance_model_1;
static float4 instance_model_2;
static float4 instance_model_3;
static float3 instance_normal_0;
static float3 instance_normal_1;
static float3 instance_normal_2;
static float3 position;
static float3 normal;
static float4 tangent;
static float4 colour;
static float2 uv;
static float4 v_col;
static float2 v_uv;
static float3 v_nrm;
static float3 v_geometry;
static float3 v_world;
static float4 v_tng;
static float v_time;
static float4 v_instance_tint;
static float4 instance_tint;

struct SPIRV_Cross_Input
{
    float3 position : TEXCOORD0;
    float4 colour : TEXCOORD1;
    float3 normal : TEXCOORD2;
    float2 uv : TEXCOORD3;
    float4 tangent : TEXCOORD4;
    float4 instance_model_0 : TEXCOORD5;
    float4 instance_model_1 : TEXCOORD6;
    float4 instance_model_2 : TEXCOORD7;
    float4 instance_model_3 : TEXCOORD8;
    float3 instance_normal_0 : TEXCOORD9;
    float3 instance_normal_1 : TEXCOORD10;
    float3 instance_normal_2 : TEXCOORD11;
    float4 instance_tint : TEXCOORD12;
};

struct SPIRV_Cross_Output
{
    float4 v_col : TEXCOORD0;
    float3 v_nrm : TEXCOORD1;
    float3 v_geometry : TEXCOORD2;
    float3 v_world : TEXCOORD3;
    float2 v_uv : TEXCOORD4;
    float4 v_tng : TEXCOORD5;
    nointerpolation float v_time : TEXCOORD6;
    float4 v_instance_tint : TEXCOORD7;
    float4 gl_Position : SV_Position;
};

float4 sample_weights(float2 uv_1)
{
    return game_weights_tex.SampleLevel(game_weights_smp, uv_1, 0.0f);
}

float param_phase()
{
    return _32_vertex_values[1].x;
}

float param_wind()
{
    return _32_vertex_values[0].x;
}

void rocco_vertex(inout Vertex vertex)
{
    float2 param = vertex.uv;
    vertex.position.x += ((sin(((vertex.time * 2.0f) + vertex.world_origin.x) + param_phase()) * param_wind()) * (vertex.colour.x * sample_weights(param).x));
}

void vert_main()
{
    float4x4 _126 = float4x4(instance_model_0, instance_model_1, instance_model_2, instance_model_3);
    float4 _164 = float4(instance_normal_0, 0.0f);
    float4 _165 = float4(instance_normal_1, 0.0f);
    float4 _166 = float4(instance_normal_2, 0.0f);
    float4x4 _168 = float4x4(_164, _165, _166, float4(0.0f, 0.0f, 0.0f, 1.0f));
    Vertex _349 = { position, normal, tangent, colour, uv, _194_render_time.x, _194_draw_info, mul(float4(position, 1.0f), _126).xyz, instance_model_3.xyz, transpose(float3x3(_164.xyz, _165.xyz, _166.xyz)) };
    Vertex param = _349;
    rocco_vertex(param);
    float4 _249 = float4(param.position, 1.0f);
    gl_Position = mul(_249, mul(_126, _194_mvp));
    v_col = param.colour;
    v_uv = param.uv;
    v_nrm = mul(float4(param.normal, 0.0f), _168).xyz;
    v_geometry = mul(float4(normal, 0.0f), _168).xyz;
    v_world = mul(_249, _126).xyz;
    v_tng = float4(mul(float4(param.tangent.xyz, 0.0f), _126).xyz, param.tangent.w * ((determinant(float3x3(instance_model_0.xyz, instance_model_1.xyz, instance_model_2.xyz)) < 0.0f) ? (-1.0f) : 1.0f));
    v_time = _194_render_time.x;
    v_instance_tint = instance_tint;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    instance_model_0 = stage_input.instance_model_0;
    instance_model_1 = stage_input.instance_model_1;
    instance_model_2 = stage_input.instance_model_2;
    instance_model_3 = stage_input.instance_model_3;
    instance_normal_0 = stage_input.instance_normal_0;
    instance_normal_1 = stage_input.instance_normal_1;
    instance_normal_2 = stage_input.instance_normal_2;
    position = stage_input.position;
    normal = stage_input.normal;
    tangent = stage_input.tangent;
    colour = stage_input.colour;
    uv = stage_input.uv;
    instance_tint = stage_input.instance_tint;
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.v_col = v_col;
    stage_output.v_uv = v_uv;
    stage_output.v_nrm = v_nrm;
    stage_output.v_geometry = v_geometry;
    stage_output.v_world = v_world;
    stage_output.v_tng = v_tng;
    stage_output.v_time = v_time;
    stage_output.v_instance_tint = v_instance_tint;
    return stage_output;
}
