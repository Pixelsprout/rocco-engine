@vs post_vs
out vec2 v_uv;
void main() {
    vec2 p = vec2(float((gl_VertexIndex << 1) & 2), float(gl_VertexIndex & 2));
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
#if SOKOL_GLSL
    v_uv = p;
#else
    v_uv = vec2(p.x, 1.0 - p.y);
#endif
}
@end
@fs post_fs
layout(binding=5) uniform game_fragment { vec4 fragment_values[16]; };
float param_mode() { return fragment_values[0].x; }
layout(binding=0) uniform texture2D scene_colour;
layout(binding=0) uniform sampler scene_colour_smp;
vec4 sample_scene_colour(vec2 uv) { return texture(sampler2D(scene_colour, scene_colour_smp), uv); }
layout(binding=1) uniform texture2D scene_depth;
layout(binding=1) uniform sampler scene_depth_smp;
vec4 sample_scene_depth(vec2 uv) { return texture(sampler2D(scene_depth, scene_depth_smp), uv); }
layout(binding=2) uniform texture2D selection_coverage;
layout(binding=2) uniform sampler selection_coverage_smp;
vec4 sample_selection_coverage(vec2 uv) { return texture(sampler2D(selection_coverage, selection_coverage_smp), uv); }
layout(binding=3) uniform texture2D selection_depth;
layout(binding=3) uniform sampler selection_depth_smp;
vec4 sample_selection_depth(vec2 uv) { return texture(sampler2D(selection_depth, selection_depth_smp), uv); }
layout(binding=1) uniform engine_post { vec4 viewport; vec4 frame; vec4 reserved_post[6]; };
in vec2 v_uv;
struct PostInput { vec2 uv; vec2 pixel_size; float time; };
vec4 rocco_post(PostInput data) {
    float depth = sample_scene_depth(data.uv).r;
    float selection = sample_selection_coverage(data.uv).r;
    float selected_depth = sample_selection_depth(data.uv).r;
    if (param_mode() < 0.5) {
        uint bits = floatBitsToUint(depth);
        return vec4(float(bits & 255u), float((bits >> 8u) & 255u),
                    float((bits >> 16u) & 255u), float((bits >> 24u) & 255u)) / 255.0;
    }
    if (param_mode() < 1.5) {
        return vec4(depth > 0.0 ? 1.0 : 0.0, selection, selected_depth > 0.0 ? 1.0 : 0.0, 1.0);
    }
    vec3 colour = sample_scene_colour(data.uv).rgb;
    // Match the existing example outline policy; mode 3 retains the zero-bias diagnostic.
    float bias = param_mode() < 2.5 ? 0.0001 : 0.0;
    float visible = selection > 0.0 && selected_depth >= depth - bias ? 1.0 : 0.0;
    return vec4(colour * 0.7 + vec3(visible * 0.2, depth * 2.0, selection * 0.1), 1.0);
}
out vec4 frag_colour;
void main() {
    PostInput data;
    data.uv = v_uv; data.pixel_size = viewport.zw; data.time = frame.x;
    frag_colour = rocco_post(data);
}
@end
@program post_ldr post_vs post_fs
