struct PostInput
{
    float2 uv;
    float2 pixel_size;
    float time;
};

cbuffer game_fragment : register(b5)
{
    float4 _37_fragment_values[16] : packoffset(c0);
};

cbuffer engine_post : register(b1)
{
    float4 _211_viewport : packoffset(c0);
    float4 _211_frame : packoffset(c1);
    float4 _211_reserved_post[6] : packoffset(c2);
};

Texture2D<float4> scene_colour : register(t0);
SamplerState scene_colour_smp : register(s0);
Texture2D<float4> scene_depth : register(t1);
SamplerState scene_depth_smp : register(s1);
Texture2D<float4> selection_coverage : register(t2);
SamplerState selection_coverage_smp : register(s2);
Texture2D<float4> selection_depth : register(t3);
SamplerState selection_depth_smp : register(s3);

static float2 v_uv;
static float4 frag_colour;

struct SPIRV_Cross_Input
{
    float2 v_uv : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 frag_colour : SV_Target0;
};

float4 sample_scene_depth(float2 uv)
{
    return scene_depth.Sample(scene_depth_smp, uv);
}

float4 sample_selection_coverage(float2 uv)
{
    return selection_coverage.Sample(selection_coverage_smp, uv);
}

float4 sample_selection_depth(float2 uv)
{
    return selection_depth.Sample(selection_depth_smp, uv);
}

float param_mode()
{
    return _37_fragment_values[0].x;
}

float4 sample_scene_colour(float2 uv)
{
    return scene_colour.Sample(scene_colour_smp, uv);
}

float4 rocco_post(PostInput data)
{
    float2 param = data.uv;
    float4 _92 = sample_scene_depth(param);
    float _93 = _92.x;
    float2 param_1 = data.uv;
    float4 _98 = sample_selection_coverage(param_1);
    float _99 = _98.x;
    float2 param_2 = data.uv;
    float4 _104 = sample_selection_depth(param_2);
    float _105 = _104.x;
    if (param_mode() < 0.5f)
    {
        uint _115 = asuint(_93);
        return float4(float(_115 & 255u), float((_115 >> 8u) & 255u), float((_115 >> 16u) & 255u), float((_115 >> 24u) & 255u)) * 0.0039215688593685626983642578125f.xxxx;
    }
    if (param_mode() < 1.5f)
    {
        return float4(float(_93 > 0.0f), _99, float(_105 > 0.0f), 1.0f);
    }
    float2 param_3 = data.uv;
    float4 _161 = sample_scene_colour(param_3);
    bool _171 = _99 > 0.0f;
    bool _179;
    if (_171)
    {
        _179 = _105 >= (_93 - ((param_mode() < 2.5f) ? 9.9999997473787516355514526367188e-05f : 0.0f));
    }
    else
    {
        _179 = _171;
    }
    return float4((_161.xyz * 0.699999988079071044921875f) + float3(float(_179) * 0.20000000298023223876953125f, _93 * 2.0f, _99 * 0.100000001490116119384765625f), 1.0f);
}

void frag_main()
{
    PostInput _232 = { v_uv, _211_viewport.zw, _211_frame.x };
    PostInput param = _232;
    frag_colour = rocco_post(param);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    v_uv = stage_input.v_uv;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.frag_colour = frag_colour;
    return stage_output;
}
