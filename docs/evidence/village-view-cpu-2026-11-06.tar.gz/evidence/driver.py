#!/usr/bin/env python3
import argparse, csv, gzip, hashlib, json, math, os, re, subprocess, sys, time
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('root',type=Path)
parser.add_argument('out',type=Path)
parser.add_argument('--binary',type=Path)
parser.add_argument('--warmup',type=int,default=1800)
parser.add_argument('--measured',type=int,default=3600)
parser.add_argument('--pixels',action='store_true')
args=parser.parse_args()
root=args.root.resolve(); out=args.out.resolve(); out.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(root/'scripts'))
from bridge import Bridge, free_port
binary=(args.binary or root/'examples/village/village.bin').resolve()
port=free_port()
env=dict(os.environ,ROCCO_BRIDGE=str(port),ROCCO_SEED='0',ROCCO_LOCKSTEP='1',ROCCO_EXIT_AFTER_FRAMES='20000',ROCCO_SPANS_CSV=str(out/'cpu.csv'))
for name in ('ROCCO_HEADLESS','ROCCO_ALLOC_REPORT','ROCCO_D3D_GPU_CSV'):
 env.pop(name,None)
report=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),warmup_steps=args.warmup,measured_steps=args.measured,command=['taskpolicy','-a',str(binary),'--retina-1080'],events=[],mode='native pixel parity; readback timings excluded from performance evidence' if args.pixels else 'controlled fixed-step CPU diagnostic',settings='full default density, all effects, Group 20 selected')
report['machine']=json.loads(subprocess.check_output([sys.executable,str(root/'bench/machine.py')],cwd=root,text=True))
(out/'processes-before.txt').write_text(subprocess.check_output(['ps','-Ao','pid,ppid,%cpu,comm'],text=True))
def save_scene(name,reply):
 with gzip.open(out/(name+'.json.gz'),'wt') as f: json.dump(reply,f,separators=(',',':'))
 scene=reply['scene']; draws=[]; groups=[]
 def walk(nodes):
  for n in nodes:
   if 'Draw' in n: draws.append(n['Draw'])
   if 'Group' in n:
    groups.append(n['Group']); walk(n['Group']['children'])
 walk(scene['nodes'])
 sample=dict(name=name,steps=reply['steps'],camera=scene['camera'],source_draws=sum(100<=d['id']<100000 for d in draws),field_draws=sum(d['id']>=100000 for d in draws),selected=[g['id'] for g in groups if g['selected']],post=scene.get('post','Bridge scene omits Post values'),emitters=len(scene['emitters']),shadow=scene['shadow'],environment=scene['environment'])
 report['events'].append(sample)
 assert sample['source_draws']==1436 and all(d['mesh'] for d in draws)
 assert sample['selected']==[20] and sample['emitters']==41
 return sample
log=(out/'host.log').open('w')
process=subprocess.Popen(report['command'],cwd=root/'examples/village',env=env,stdout=log,stderr=subprocess.STDOUT)
report['pid']=process.pid
try:
 with Bridge.connect(port,wait=60,process=process) as bridge:
  report['hello']=bridge.hello()
  report['step_hz']=report['hello']['step_hz']
  assert report['step_hz']==120
  for ready_step in range(1,129):
   bridge.step(1)
   if bridge.scene()['scene']['nodes']: break
  else: raise AssertionError('Village readiness timed out')
  report['ready_steps']=ready_step
  print('Ready:',ready_step,flush=True)
  bridge.tell('effects','all'); bridge.tell('view','walk'); bridge.step(2)
  bridge.step(1,mouse=[125.7,0]); bridge.step(1,tap=['Enter'])
  selected=bridge.scene()
  save_scene('selected',selected)
  report['dimensions']=bridge.screenshot(str(out/'physical-check.png'))
  assert report['dimensions']['physical']==[1920,1080]
  report['warmup_begin']=selected['steps']
  bridge.step(args.warmup)
  print('Warmup complete:',args.warmup,flush=True)
  bridge.tell('view','tour')
  start=bridge.scene()
  report['measure_start_after_steps']=start['steps']
  report['measure_start_wall']=time.time()
  for segment in range(args.measured//600):
   reply=bridge.step(600)
   print('Route steps:',(segment+1)*600,flush=True)
   if args.pixels:
    sample=save_scene('route-'+str((segment+1)*600),bridge.scene())
    shot=bridge.screenshot(str(out/('route-'+str((segment+1)*600)+'.png')))
    assert shot['physical']==[1920,1080]
    sample['sha256']=hashlib.sha256(Path(shot['path']).read_bytes()).hexdigest()
   report['events'].append(dict(name='route-segment',steps=reply['steps'],segment=segment,wall=time.time()))
  remainder=args.measured%600
  if remainder: bridge.step(remainder)
  report['measure_end_wall']=time.time()
  end=bridge.scene()
  report['measure_end_at_steps']=end['steps']
  save_scene('route-end',end)
  report['warmup_seconds']=args.warmup/report['step_hz']
  report['route_seconds']=args.measured/report['step_hz']
  bridge.quit()
 assert process.wait(timeout=30)==0
finally:
 if process.poll() is None: process.terminate(); process.wait(timeout=30)
 log.close()
 (out/'run.json').write_text(json.dumps(report,indent=2)+'\n')
rows=list(csv.DictReader((out/'cpu.csv').open()))
active=[]; paused=[]; cumulative=0
for row in rows:
 steps=int(row['steps']); cumulative+=steps
 if report['measure_start_after_steps']<cumulative<=report['measure_end_at_steps']:
  (active if steps else paused).append(row)
assert len(active)==args.measured and all(int(r['steps'])==1 for r in active)
all_span_names=[n for n in rows[0] if n.endswith('_us') and n!='span_cost_us']
span_names=[n for n in all_span_names if not n.startswith('attribution_')]
step_names=['input_us','step_us','commands_us','view_us','queries_us','query_results_us']
def stats(values):
 v=sorted(values)
 return dict(samples=len(v),p50_ms=v[math.ceil(.50*len(v))-1]/1000,p95_ms=v[math.ceil(.95*len(v))-1]/1000,p99_ms=v[math.ceil(.99*len(v))-1]/1000,max_ms=v[-1]/1000)
summary=dict(raw_frames=len(rows),active_measured_frames=len(active),paused_route_frames=len(paused),all_samples_preserved=True,percentile='nearest rank',mode=report['mode'],step_hz=report['step_hz'],route_seconds=report['route_seconds'],spans={n:stats([float(r[n]) for r in active]) for n in all_span_names})
summary['actual_one_step_work']=stats([sum(float(r[n]) for n in span_names) for r in active])
summary['derived_two_step_work']=stats([sum(float(r[n]) for n in span_names)+sum(float(r[n]) for n in step_names) for r in active])
summary['diagnostics']=re.findall(r'(?im)^.*(?:panic|\[error\]|\[warn\]|not in|failed|absent|invalid|capacity|first [0-9]+).*$',(out/'host.log').read_text())
assert not summary['diagnostics'],summary['diagnostics']
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(out=str(out),actual=summary['actual_one_step_work'],derived=summary['derived_two_step_work'],interpolation=summary['spans']['interpolation_us']),indent=2),flush=True)
