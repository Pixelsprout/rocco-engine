from pathlib import Path
import csv, gzip, hashlib, json, math, statistics

OUT = Path('/tmp/rocco-view-evidence')

def read_json(path):
    return json.loads(path.read_text())

def stats(values):
    ordered = sorted(values)
    return dict(samples=len(ordered), p50_ms=ordered[math.ceil(.50*len(ordered))-1]/1000,
                p95_ms=ordered[math.ceil(.95*len(ordered))-1]/1000,
                p99_ms=ordered[math.ceil(.99*len(ordered))-1]/1000, max_ms=ordered[-1]/1000)

def measured(path):
    report = read_json(path/'run.json')
    rows = list(csv.DictReader((path/'cpu.csv').open()))
    active = []
    cumulative = 0
    for row in rows:
        cumulative += int(row['steps'])
        if report['measure_start_after_steps'] < cumulative <= report['measure_end_at_steps'] and int(row['steps']):
            active.append(dict(row, cumulative_step=cumulative))
    assert report['ready_steps'] == 96
    assert report['warmup_steps'] == 1800 and report['measured_steps'] == 3600
    assert report['measure_start_after_steps'] == 1900 and report['measure_end_at_steps'] == 5500
    assert len(active) == 3600 and all(int(row['steps']) == 1 for row in active)
    return report, rows, active

runs = {}
for label in ('baseline', 'candidate'):
    path = OUT/('cpu-'+label)
    report, raw, rows = measured(path)
    summary = read_json(path/'summary.json')
    spikes = [dict(frame=int(row['frame']), cumulative_step=row['cumulative_step'],
                   route_step=row['cumulative_step']-1900,
                   step_us=float(row['step_us']), view_us=float(row['view_us']),
                   step_view_us=float(row['step_us'])+float(row['view_us']))
              for row in rows if float(row['step_us']) >= 1000]
    runs[label] = dict(ready_steps=report['ready_steps'], setup_steps=4, warmup_steps=1800,
                       measured_actual_fixed_steps=3600, measure_start_after_steps=1900,
                       measure_end_at_steps=5500, step_hz=report['step_hz'], raw_frames=len(raw),
                       measured_active_frames=len(rows), binary_sha256=report['binary_sha256'],
                       step=summary['spans']['step_us'], view=summary['spans']['view_us'],
                       step_and_view=stats([float(row['step_us'])+float(row['view_us']) for row in rows]),
                       actual_one_step_cpu=summary['actual_one_step_work'],
                       derived_two_step_cpu=summary['derived_two_step_work'],
                       step_spans_at_least_1ms=spikes, diagnostics=summary['diagnostics'])
assert runs['candidate']['view']['p95_ms'] < runs['baseline']['view']['p95_ms']
assert runs['candidate']['step_and_view']['p95_ms'] < runs['baseline']['step_and_view']['p95_ms']
assert runs['candidate']['actual_one_step_cpu']['p95_ms'] < runs['baseline']['actual_one_step_cpu']['p95_ms']
for label in ('selected', 'route-end'):
    baseline = json.loads(gzip.open(OUT/'cpu-baseline'/(label+'.json.gz')).read())
    candidate = json.loads(gzip.open(OUT/'cpu-candidate'/(label+'.json.gz')).read())
    assert baseline == candidate, label
preparation = read_json(OUT/'final-preparation.json')
memory = {}
for label in ('baseline','candidate'):
    rows = [row for row in preparation if row['label']==label]
    memory[label] = dict(loaded_callback_us=[row['last_loaded']['loaded_us'] for row in rows],
                         loaded_callback_median_us=statistics.median(row['last_loaded']['loaded_us'] for row in rows),
                         after_loaded_requested_bytes=rows[0]['last_loaded']['after'],
                         steady_requested_bytes=rows[0]['last_views'][-1]['current'],
                         peak_requested_bytes=rows[0]['last_views'][-1]['peak'])
result = dict(build=read_json(OUT/'final-build.json'), runs=runs, preparation=memory,
              exact_selected_and_route_end_scene_equality=True,
              membership_probe=read_json(Path('/tmp/rocco-view-membership-profile/membership.json')),
              all_measured_rows_included=True, raw_samples_preserved=True,
              cpu_target_scope='isolated View change with verified Surface cache host; depth batching is separate',
              final_gpu_real_pacing_pc_and_human_acceptance='separate')
(OUT/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(runs={key:{field:row[field] for field in ('step','view','step_and_view','actual_one_step_cpu','derived_two_step_cpu')} for key,row in runs.items()}, candidate_spike_count=len(runs['candidate']['step_spans_at_least_1ms']), preparation=memory),indent=2))
