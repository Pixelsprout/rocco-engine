from pathlib import Path
import argparse, json, os, re, subprocess

parser = argparse.ArgumentParser()
parser.add_argument('root', type=Path)
parser.add_argument('out', type=Path)
parser.add_argument('--stage', choices=['variants', 'complete-cache'], required=True)
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=False)
records = []
prefix = 'diagnostic-' if args.stage == 'variants' else 'final-diagnostic-'
for iteration in range(1, 4):
    for label in ('baseline', 'candidate'):
        stem = f'{label}-{iteration}'
        env = dict(os.environ, ROCCO_HEADLESS='1', ROCCO_LOCKSTEP='1',
                   ROCCO_EXIT_AFTER_FRAMES='100', ROCCO_NO_GAMEPADS='1',
                   ROCCO_SPANS_CSV=str((args.out/(stem+'.csv')).resolve()))
        env.pop('ROCCO_BRIDGE', None)
        command = ['taskpolicy', '-a', str((args.root/'examples/village'/(prefix+label+'.bin')).resolve())]
        with (args.out/(stem+'.log')).open('w') as log:
            subprocess.run(command, cwd=args.root/'examples/village', env=env,
                           stdout=log, stderr=subprocess.STDOUT, check=True, timeout=60)
        text = (args.out/(stem+'.log')).read_text()
        loaded = [dict(loaded_us=float(t), before=int(b), after=int(a), peak=int(p))
                  for t,b,a,p in re.findall(r'view_prepare loaded_us=([0-9.]+) before=([0-9]+) after=([0-9]+) peak=([0-9]+)', text)]
        views = [dict(current=int(c), peak=int(p))
                 for c,p in re.findall(r'view_live current=([0-9]+) peak=([0-9]+)', text)]
        assert len(loaded) == 96
        if args.stage == 'complete-cache':
            assert len(views) == 101
        records.append(dict(label=label, iteration=iteration, last_loaded=loaded[-1],
                            last_views=views[-3:], command=command))
(args.out/'summary.json').write_text(json.dumps(records, indent=2)+'\n')
