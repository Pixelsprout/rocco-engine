from pathlib import Path
import hashlib, json, tarfile, os

ROOT = Path('/tmp/rocco-village-view')
OUT = Path('/tmp/rocco-view-evidence')
DEST = ROOT/'docs/evidence'
DEST.mkdir(parents=True, exist_ok=True)
STEM = 'village-view-cpu-2026-11-06'
comparison = json.loads((OUT/'comparison.json').read_text())
parity = json.loads((OUT/'pixel-parity.json').read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

binaries = [
    ('baseline.bin', ROOT/'examples/village/baseline.bin'),
    ('prepared-nodes.bin', ROOT/'examples/village/candidate.bin'),
    ('candidate.bin', ROOT/'examples/village/village.bin'),
    ('membership-probe.bin', ROOT/'examples/village/membership-probe.bin'),
    ('diagnostic-baseline.bin', ROOT/'examples/village/diagnostic-baseline.bin'),
    ('diagnostic-candidate.bin', ROOT/'examples/village/diagnostic-candidate.bin'),
    ('final-diagnostic-baseline.bin', ROOT/'examples/village/final-diagnostic-baseline.bin'),
    ('final-diagnostic-candidate.bin', ROOT/'examples/village/final-diagnostic-candidate.bin'),
    ('verified-host.a', ROOT/'platform/targets/arm64mac/libhost.a'),
    ('diagnostic-host.a', Path('/tmp/rocco-view-diagnostic-host.a')),
    ('final-diagnostic-host.a', Path('/tmp/rocco-view-final-diagnostic-host.a')),
]
manifest = [dict(name=name, source=str(path), sha256=sha(path), bytes=path.stat().st_size) for name,path in binaries]
(OUT/'binaries.json').write_text(json.dumps(manifest,indent=2)+'\n')
full_archive = Path('/tmp/rocco-village-view-full-evidence.tar.gz')
archive = DEST/(STEM+'.tar.gz')
roots = [('evidence',OUT), ('attribution-baseline',Path('/tmp/rocco-view-profile-baseline')),
         ('prepared-node-diagnostic',Path('/tmp/rocco-view-candidate-diagnostic')),
         ('membership-probe',Path('/tmp/rocco-view-membership-profile'))]
payloads = []
for prefix,root in roots:
    for folder,dirs,names in os.walk(root,followlinks=False):
        for name in dirs+names:
            path = Path(folder)/name
            assert not path.is_symlink(), path
        for name in sorted(names):
            path = Path(folder)/name
            if path == OUT/'preservation-manifest.json':
                continue
            assert path.is_file(), path
            assert name.endswith(('.json','.json.gz','.csv','.log','.py','.roc','.patch','.txt','.png')), path
            assert 'assets' not in path.relative_to(root).parts, path
            payloads.append((prefix+'/'+path.relative_to(root).as_posix(),path))
payloads += [('binaries/'+name,path) for name,path in binaries]
assert len({name for name,path in payloads}) == len(payloads)
assert all(path.resolve() not in (archive.resolve(),full_archive.resolve()) for name,path in payloads)
assert all(not path.is_symlink() and path.is_file() for name,path in payloads)
file_manifest = [dict(name=name,source=str(path),bytes=path.stat().st_size,sha256=sha(path)) for name,path in sorted(payloads)]
manifest_path = OUT/'preservation-manifest.json'
manifest_path.write_text(json.dumps(dict(files=file_manifest,symlinks=[],runtime_assets_included=False,
                                        archive_uses_explicit_files=True),indent=2)+'\n')
expected = {row['name']:row for row in file_manifest}
expected['preservation-manifest.json'] = dict(bytes=manifest_path.stat().st_size,sha256=sha(manifest_path))
full_payloads = sorted(payloads)+[('preservation-manifest.json',manifest_path)]
compact_payloads = [(name,path) for name,path in full_payloads
                    if not name.startswith('binaries/') and not name.endswith(('.png','.json.gz'))]
print(json.dumps(dict(full_input_bytes=sum(path.stat().st_size for name,path in full_payloads),
                      compact_input_bytes=sum(path.stat().st_size for name,path in compact_payloads),
                      full_files=len(full_payloads),compact_files=len(compact_payloads),
                      symlinks=0,runtime_asset_files=0),indent=2),flush=True)

class BoundedWriter:
    def __init__(self,raw,limit):
        self.raw,self.limit,self.written = raw,limit,0
    def write(self,data):
        if self.written+len(data)>self.limit:
            raise RuntimeError('Archive exceeded its explicit byte bound')
        self.written += len(data)
        return self.raw.write(data)
    def __getattr__(self,name):
        return getattr(self.raw,name)

def create_and_verify(destination,files):
    partial = destination.with_name(destination.name+'.partial')
    limit = sum(path.stat().st_size for name,path in files)+8*1024*1024
    with partial.open('wb') as raw:
        with tarfile.open(fileobj=BoundedWriter(raw,limit),mode='w:gz',compresslevel=6) as tar:
            for name,path in files:
                source = path.stat()
                info = tarfile.TarInfo(name)
                info.size,info.mode,info.mtime = source.st_size,source.st_mode & 0o777,source.st_mtime
                with path.open('rb') as data:
                    tar.addfile(info,data)
    seen = set()
    with tarfile.open(partial,'r:gz') as tar:
        for info in tar:
            assert info.isfile() and info.name not in seen,info.name
            assert info.name in expected and info.size==expected[info.name]['bytes'],info.name
            digest = hashlib.sha256()
            data = tar.extractfile(info)
            for block in iter(lambda:data.read(1024*1024),b''):
                digest.update(block)
            assert digest.hexdigest()==expected[info.name]['sha256'],info.name
            seen.add(info.name)
    assert seen == {name for name,path in files}
    partial.replace(destination)
    return dict(path=str(destination),file=destination.name,sha256=sha(destination),
                bytes=destination.stat().st_size,verified_members=len(seen),
                verified='Every member SHA-256 and size matches its source manifest')

full_info = create_and_verify(full_archive,full_payloads)
compact_info = create_and_verify(archive,compact_payloads)
summary = dict(comparison,pixel_parity=parity,roc_tests_passed=187,
               artifact=compact_info,full_archive=full_info,
               preserved_files=file_manifest,preservation_manifest_sha256=sha(manifest_path),
               binaries=manifest,reporting_basis=22,
               scope='isolated village construction optimization; complete content retained')
(DEST/(STEM+'.json')).write_text(json.dumps(summary,indent=2)+'\n')

baseline = comparison['runs']['baseline']; candidate = comparison['runs']['candidate']
rows = []
for label,key in [('Step','step'),('View','view'),('Step + View','step_and_view'),('Actual CPU, one fixed step','actual_one_step_cpu'),('Derived CPU, two fixed steps','derived_two_step_cpu')]:
    a,b=baseline[key],candidate[key]
    rows.append(f"| {label} | {a['p50_ms']:.3f} | {a['p95_ms']:.3f} | {a['p99_ms']:.3f} | {b['p50_ms']:.3f} | {b['p95_ms']:.3f} | {b['p99_ms']:.3f} |")
text = f'''# Village View CPU and parity evidence

The cache reduces Step plus View p95 from 8.443 ms to 0.424 ms.
All 24 visibility rebuilds remain in the measured samples.
The isolated CPU p95 remains 22.145 ms, above the 16.67 ms target.
Depth batching is absent from both runs.
Combined measurements must determine the remaining CPU work.
The reporting basis remains 22 items.

## Change

Preparation creates immutable field Nodes for both grass material modes.
Each ready Step compares exact visibility for every relevant field ID.
The cache rebuilds when visibility membership or Node settings change.
Its key includes lighting, vegetation, and selected Group settings.
Ready loaded callbacks rebuild preparation and cached Nodes.
Failed readiness clears the Node cache.
View computes current camera, shader values, queries, environment, effects, emitters, cursor, and UI.
Each fixed step still calls View.
Field density, source placement order, the distance envelope, and source casting remain unchanged.

## Build and workload

The baseline source is `25faba2`.
The candidate source is `91da4b99d2160be0d366dea2e55b266541344796`.
Both binaries use the verified Surface reuse host.
The host SHA-256 is `{comparison['build']['host_sha256']}`.
Both use pinned Odin, optimized Roc, release Spans, and `taskpolicy -a`.
The archive records exact commands, compiler versions, archive hashes, and binary hashes.
The driver records the current worktree commit for both binaries.
`final-build.json` identifies each binary's actual source commit.

Each run loads all 93 meshes and 1,436 source placements.
Field density stays at 22,000, with all effects and Group 20 selected.
The physical output stays at 1920 by 1080 pixels.
Readiness occurs at fixed step 96.
Four setup steps precede the unchanged 1,800-step warmup.
Measurement includes all 3,600 fixed steps from cumulative steps 1,901 through 5,500.
Every measured frame contains one actual fixed step.
Paused frames and warmup rows remain in the raw CSV files.
Sampling and diagnostic hosts are absent from these timing runs.

## CPU results

All values use milliseconds and nearest-rank percentiles.

| Work | Baseline p50 | Baseline p95 | Baseline p99 | Candidate p50 | Candidate p95 | Candidate p99 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
{chr(10).join(rows)}

The candidate has exactly 24 Step spans above 1 ms.
All occur within the first 600 route steps.
`comparison.json` records every spike's frame, fixed step, Step time, and View time.
Candidate maximum Step time is 12.721 ms.
Candidate maximum Step plus View time is 13.449 ms.
These samples remain in every reported percentile.
Derived CPU adds another copy of each row's fixed-step spans.
This estimate does not establish real pacing.

## Attribution and memory

Native sampling identified repeated copies, allocations, and reference counts within the inlined View path.
The bounded prepared-Node experiment reduced median View time from 6.916 ms to 5.128 ms.
Those attribution runs used 120 warmup steps and 600 measured steps.
The baseline sample includes profiler overhead.
A separate membership probe counted 24 changes across 600 route steps.
Its median Step time increased from 0.096375 ms to 0.113167 ms.

Three alternating headless startup pairs measured requested Roc allocation bytes.
These counters exclude allocator headers, native allocations, GPU memory, and RSS.
After ready Hero Views, requested live bytes increase from 25,122,664 to 25,362,704.
The difference is 240,040 bytes because Scenes share the cached Node list.
Peak requested bytes increase from 34,358,136 to 35,339,608.
The final three View snapshots match within each run.
Both prepared Node variants remain available for controls.

The last-ready callback median increases from 6.499 ms to 12.391 ms.
The candidate callback includes the initial Node build.
The baseline performs that build during its first ready View.
The candidate callback samples are 10.332, 31.053, and 12.391 ms.
The raw logs retain all three samples.
These instrumented headless timings provide diagnostics, separate from acceptance timing.
The archive preserves both diagnostic host patches and their build hashes.
The verified host was restored before final timing and parity.

## Semantic and pixel verification

All 187 optimized Roc tests pass.
Tests compare complete Scene values across cameras, controls, selected Groups, and loaded callbacks.
A synthetic route compares every Scene across 3,600 fixed steps.
Field tests compare every Node against the original filter and map operations.
They cover full placements, density controls, exact distance boundaries, and changed IDs with an unchanged visible count.

Seven native 1920 by 1080 images are byte-identical to the verified Surface baseline.
All eight Bridge snapshots also match exactly.
Bridge omits Post and shader values; the Roc comparisons include both.
Route captures use cumulative steps 2,500, 3,100, 3,700, 4,300, 4,900, and 5,500.
The initial selected image also matches.
Visual inspection confirms the complete village at route step 600.
Pixel runs provide parity evidence, separate from CPU timing.
The reference binary SHA-256 is `{parity['reference_binary_sha256']}`.
The reference archive is [Surface reuse evidence](surface-reuse-cpu-2026-11-06.tar.gz).

## Retained artifacts

[Machine-readable results]({STEM}.json) contain the comparison, hashes, spike records, and parity results.
[Committed timing evidence]({STEM}.tar.gz) contains every CSV, log, build record, probe, and patch.
The full archive preserves every screenshot, Scene snapshot, and measurement binary outside Git.
Its path is `{full_info["path"]}`.
Its SHA-256 is `{full_info["sha256"]}`.
The result JSON records every preserved file digest and both archive verification results.
Original files remain at their recorded paths.
The archive SHA-256 is `{summary['artifact']['sha256']}`.
GPU timing, real pacing, PC evidence, and human acceptance remain separate.
'''
(DEST/(STEM+'.md')).write_text(text)
print(json.dumps(dict(compact=compact_info,full=full_info,binary_count=len(binaries)),indent=2))
