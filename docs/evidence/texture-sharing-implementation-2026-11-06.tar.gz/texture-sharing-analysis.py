import csv,json,pathlib
paths={
 'baseline-lightweight':'/tmp/texture-sharing-baseline-evidence/lightweight',
 'baseline-memory':'/tmp/texture-sharing-baseline-evidence/memory',
 'initial-lightweight':'/tmp/village-texture-sharing-lightweight-20261106',
 'initial-memory':'/tmp/village-texture-sharing-memory-20261106',
 'final-lightweight-before-cleanup':'/tmp/village-texture-sharing-final-lightweight-20261106',
 'clean-lightweight':'/tmp/village-texture-sharing-clean-lightweight-20261106',
 'clean-memory':'/tmp/village-texture-sharing-clean-memory-20261106',
}
result={}
for name,path in paths.items():
 p=pathlib.Path(path)
 if not (p/'boundaries.csv').exists():continue
 rows=list(csv.DictReader((p/'boundaries.csv').open()));cpu=list(csv.DictReader((p/'cpu.csv').open()));cpu_by_id={int(x['frame']):x for x in cpu}
 selected=[x for x in rows if int(x['step_before'])>=216]
 last_load_frame=max(int(x['frame']) for x in rows if int(x['step_before'])<=96)
 loading=[x for x in cpu if int(x['frame'])<=last_load_frame]
 summary=json.loads((p/'summary.json').read_text()) if (p/'summary.json').exists() else {}
 slow=[]
 for i,x in enumerate(rows[:-1]):
  interval=(int(rows[i+1]['start_tick'])-int(x['start_tick']))/1e6
  if int(x['step_before'])>=216 and interval>=30:
   spans=cpu_by_id.get(int(x['frame']),{})
   slow.append({'frame':int(x['frame']),'interval_ms':interval,'begin_pass_ms':int(x.get('begin_pass_ticks',0))/1e6,'drawable_ms':int(x.get('drawable_ticks',0))/1e6,'cpu_ms':sum(float(v) for k,v in spans.items() if k.endswith('_us') and k!='span_cost_us')/1000})
 entry={'callback':summary.get('moving_interval_ms'),'cpu':summary.get('moving_cpu',{}).get('frame_cpu_work_ms'),'pass_entry':summary.get('begin_pass_ms'),'drawable':summary.get('drawable_ms'),'slow_samples':slow,'loading_command_seconds':sum(float(x['commands_us']) for x in loading)/1e6,'first_frame_to_settled_seconds':(int(selected[0]['start_tick'])-int(rows[0]['start_tick']))/1e9,'physical_sizes':sorted(set((x['width'],x['height'],x['dpi']) for x in rows))}
 monitor=[json.loads(x) for x in (p/'monitor.jsonl').read_text().splitlines()]
 entry['pressure_samples']=len(monitor);entry['pressure_states']=sorted(set(x['pressure'] for x in monitor))
 if monitor and 'game' in monitor[0]:
  valid=[x for x in monitor if x['game'].get('returncode')==0]
  settled=[x for x in valid if x['tick']>=int(selected[0]['start_tick'])]
  earlier=[x for x in valid if x['tick']<int(selected[0]['start_tick'])]
  entry['settled_memory_samples']=len(settled)
  for key in ['resident_size','phys_footprint']:
   entry[key]={'settled_min':min(x['game'][key] for x in settled),'settled_max':max(x['game'][key] for x in settled),'all_max':max(x['game'][key] for x in valid),'loading_and_settling_max':max(x['game'][key] for x in earlier)}
 result[name]=entry
print(json.dumps(result,indent=2))
pathlib.Path('/tmp/texture-sharing-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
