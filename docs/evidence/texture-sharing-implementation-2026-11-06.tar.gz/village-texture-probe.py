from pathlib import Path
import sys
original=Path('/tmp/village-stutter-memory.py' if sys.argv[1]=='memory' else '/tmp/village-stutter-waits.py').read_text()
original=original.replace("binary=root/'examples/village/village-waits.bin'", "binary=root/'examples/village/village-texture-shared.bin'")
original=original.replace("ROCCO_SEED='0'", "ROCCO_SEED='0',ROCCO_TEXTURE_CACHE_REPORT='1'")
# Preserve a separate, exact script for each run.
out=Path(sys.argv[2])
script=Path('/tmp/village-texture-'+sys.argv[1]+'-run.py')
script.write_text(original)
sys.argv=[str(script),str(out)]
exec(compile(original,str(script),'exec'))
