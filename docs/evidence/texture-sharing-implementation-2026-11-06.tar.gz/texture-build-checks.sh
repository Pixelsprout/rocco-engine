#!/bin/sh
set -eu
export PATH=/Users/braedenfoster/tools/roc_nightly-macos_apple_silicon-2026-10-11-7d256b9:$PATH
scripts/host-check.sh
python3 -m unittest discover -s scripts -p 'test_village*.py'
