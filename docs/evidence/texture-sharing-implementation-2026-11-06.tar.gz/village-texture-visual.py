import os,sys,subprocess,time,json,threading,pathlib,hashlib
root=pathlib.Path('/Users/braedenfoster/playground/rocco-engine')
sys.path.insert(0,str(root/'scripts'))
from bridge import Bridge,free_port
name=sys.argv[1];out=pathlib.Path(sys.argv[2]);out.mkdir(exist_ok=False)
binary=root/'examples/village'/('village-waits.bin' if name=='baseline' else 'village-texture-shared.bin')
port=free_port();stop=threading.Event();game=None;records=[]
def pressure(): return subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True).strip()
def monitor():
 while not stop.is_set():
  p=pressure();records.append({'tick':time.monotonic_ns(),'pressure':p})
  if p!='1':
   if game and game.poll() is None:game.terminate()
   return
  stop.wait(1)
env={k:v for k,v in os.environ.items() if not k.startswith('ROCCO_')}
env.update(ROCCO_BRIDGE=str(port),ROCCO_DEBUG_CAMERA='1',ROCCO_ASSETS=str(root/'examples/village/assets'),ROCCO_SEED='0',ROCCO_TEXTURE_CACHE_REPORT='1',ROCCO_SPANS_CSV=str(out/'cpu.csv'),ROCCO_EXIT_AFTER_FRAMES='5000')
if len(sys.argv)>3 and sys.argv[3]=='game':env.pop('ROCCO_DEBUG_CAMERA')
result={'binary':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'environment':{k:v for k,v in env.items() if k.startswith('ROCCO_')},'captures':[]}
try:
 assert pressure()=='1'
 with (out/'host.log').open('w') as log:
  game=subprocess.Popen([str(binary)],cwd=binary.parent,env=env,stdout=log,stderr=subprocess.STDOUT)
  thread=threading.Thread(target=monitor);thread.start()
  with Bridge.connect(port,wait=75,process=game) as bridge:
   result['hello']=bridge.hello()
   previous=0
   for step in [240]:
    result['captures'].append({'step':step,'reply':bridge.step(step-previous)})
    scene=bridge.scene();(out/f'scene-{step}.json').write_text(json.dumps(scene))
    result['captures'][-1]['screenshot']=bridge.screenshot(str(out/f'frame-{step}.png'))
    previous=step
   for index, view in enumerate(['foliage','canopy','square']):
    bridge.tell('view',view)
    bridge.step(1)
    phase=241+index
    scene=bridge.scene();(out/f'scene-{view}.json').write_text(json.dumps(scene))
    result['captures'].append({'view':view,'step':phase,'screenshot':bridge.screenshot(str(out/f'frame-{view}.png'))})
   bridge.quit()
  result['exit']=game.wait(timeout=10)
except BaseException as e:result['failure']=repr(e)
finally:
 stop.set()
 if 'thread' in locals():thread.join(timeout=3)
 if game and game.poll() is None:
  game.terminate()
  try:game.wait(timeout=10)
  except subprocess.TimeoutExpired:game.kill();game.wait()
 result['pressure']=records
 (out/'run.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
