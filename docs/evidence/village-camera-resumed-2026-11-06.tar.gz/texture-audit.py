import json,struct,hashlib,collections
from pathlib import Path
import io
records=[]
for name in json.loads(Path('/tmp/village-mesh-paths.json').read_text()):
 data=Path(name).read_bytes();length,kind=struct.unpack_from('<II',data,12);j=json.loads(data[20:20+length]);off=20+length;binary=data[off+8:]
 for i,img in enumerate(j.get('images',[])):
  if 'bufferView'not in img:continue
  v=j['bufferViews'][img['bufferView']];raw=binary[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]
  assert raw[:8]==b'\x89PNG\r\n\x1a\n', (name,i,img);w,h=struct.unpack_from('>II',raw,16);pixels=0;x,y=w,h
  while True:
   pixels+=x*y
   if x==y==1:break
   x=max(1,x//2);y=max(1,y//2)
  records.append({'mesh':name,'image':i,'width':w,'height':h,'encoded_bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'rgba8_mip_bytes':pixels*4})
unique={r['sha256']:r for r in records}
result={'meshes':len(json.loads(Path('/tmp/village-mesh-paths.json').read_text())),'images':len(records),'unique_encoded_images':len(unique),'rgba8_mip_bytes_per_mesh_image':sum(r['rgba8_mip_bytes'] for r in records),'rgba8_mip_bytes_unique_encoded_images':sum(r['rgba8_mip_bytes'] for r in unique.values()),'dimensions':dict(collections.Counter(f"{r['width']}x{r['height']}"for r in records)),'records':records}
Path('/tmp/village-stutter-memory-20261106/texture-audit.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='records'})
