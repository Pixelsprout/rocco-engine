import subprocess, os, time, json, pathlib, hashlib, sys, ctypes
root=pathlib.Path('/Users/braedenfoster/playground/rocco-engine')
out=pathlib.Path(sys.argv[1]);out.mkdir(exist_ok=False)
binary=root/'examples/village/village-waits.bin'
class Usage(ctypes.Structure):
    _fields_=[('uuid',ctypes.c_uint8*16)]+[(x,ctypes.c_uint64) for x in ('user_time','system_time','pkg_idle_wkups','interrupt_wkups','pageins','wired_size','resident_size','phys_footprint','proc_start_abstime','proc_exit_abstime')]
lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
lib.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p];lib.proc_pid_rusage.restype=ctypes.c_int
assert ctypes.sizeof(Usage)==96
def usage(pid):
    u=Usage();rc=lib.proc_pid_rusage(pid,0,ctypes.byref(u))
    return {'returncode':rc,'errno':ctypes.get_errno(),**({k:getattr(u,k) for k in ('resident_size','phys_footprint','wired_size','pageins')} if rc==0 else {})}
def now():return time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)
def command(cmd):
    try:
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=5);return {'command':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    except subprocess.TimeoutExpired:return {'command':cmd,'error':'timeout'}
env={k:v for k,v in os.environ.items() if not k.startswith('ROCCO_')}
env.update(ROCCO_DEBUG_CAMERA='1',ROCCO_DEBUG_CAMERA_SWEEP='1',ROCCO_CAPTURE_DEBUG_CAMERA='1',ROCCO_CAPTURE_CSV=str(out/'boundaries.csv'),ROCCO_SPANS_CSV=str(out/'cpu.csv'),ROCCO_EXIT_AFTER_FRAMES='1200',ROCCO_ASSETS=str(root/'examples/village/assets'),ROCCO_SEED='0')
manifest={'binary':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'environment':{k:v for k,v in env.items() if k.startswith('ROCCO_')},'clock':'CLOCK_MONOTONIC_RAW nanoseconds','start_tick':now(),'limit_seconds':90,'system_before':{'pressure':command(['memory_pressure','-Q']),'vm':command(['vm_stat'])}}
game=None;sampled=False
try:
    with (out/'host.log').open('w') as h,(out/'monitor.jsonl').open('w') as m:
        pressure=subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True).strip()
        if pressure!='1':raise RuntimeError('Initial memory pressure '+pressure)
        game=subprocess.Popen([str(binary)],cwd=root/'examples/village',env=env,stdout=h,stderr=subprocess.STDOUT);manifest['game_pid']=game.pid
        start=time.monotonic()
        while game.poll() is None and time.monotonic()-start<90:
            pressure=subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True).strip()
            row={'tick':now(),'pressure':pressure,'game':usage(game.pid),'vm':command(['vm_stat']),'pressure_query':command(['memory_pressure','-Q'])}
            processes=subprocess.check_output(['ps','-axo','pid,ppid,%cpu,%mem,rss,comm'],text=True).splitlines()
            row['top']=sorted(processes[1:],key=lambda l:float(l.split()[2]),reverse=True)[:15]
            m.write(json.dumps(row)+'\n');m.flush()
            if pressure!='1':manifest['interrupted']='memory pressure';game.terminate();break
            if not sampled and time.monotonic()-start>28:
                sampled=True;manifest['footprint_start_tick']=now()
                manifest['footprint']=command(['footprint','-p',str(game.pid),'-f','bytes','--swapped','--wired'])
                manifest['footprint_end_tick']=now()
            time.sleep(2)
        if game.poll() is None:manifest.setdefault('interrupted','timeout');game.terminate()
        manifest['game_exit']=game.wait(timeout=15)
except BaseException as e:manifest['failure']=repr(e)
finally:
    if game and game.poll() is None:
        game.terminate()
        try:game.wait(timeout=10)
        except subprocess.TimeoutExpired:game.kill();game.wait()
    manifest['end_tick']=now();manifest['system_after']={'pressure':command(['memory_pressure','-Q']),'vm':command(['vm_stat'])}
    (out/'run.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k not in ('footprint','system_before','system_after','environment')},indent=2))
