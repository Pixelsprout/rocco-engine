import subprocess, os, time, json, pathlib, hashlib, sys
root=pathlib.Path('/Users/braedenfoster/playground/rocco-engine')
out=pathlib.Path(sys.argv[1]); out.mkdir(exist_ok=False)
binary=root/'examples/village/village-waits.bin'
env={k:v for k,v in os.environ.items() if not k.startswith('ROCCO_')}
env.update(ROCCO_DEBUG_CAMERA='1', ROCCO_DEBUG_CAMERA_SWEEP='1', ROCCO_CAPTURE_DEBUG_CAMERA='1', ROCCO_CAPTURE_CSV=str(out/'boundaries.csv'),ROCCO_SPANS_CSV=str(out/'cpu.csv'),ROCCO_EXIT_AFTER_FRAMES='1200',ROCCO_ASSETS=str(root/'examples/village/assets'), ROCCO_SEED='0')
manifest={'binary':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'environment':{k:v for k,v in env.items() if k.startswith('ROCCO_')},'start_monotonic_ns':time.monotonic_ns(),'limit_seconds':90}
game=None
try:
    with (out/'host.log').open('w') as h,(out/'monitor.jsonl').open('w') as m:
        pressure=subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True).strip()
        if pressure != '1':raise RuntimeError('Initial memory pressure '+pressure)
        game=subprocess.Popen([str(binary)],cwd=root/'examples/village',env=env,stdout=h,stderr=subprocess.STDOUT)
        manifest['game_pid']=game.pid
        start=time.monotonic()
        while game.poll() is None and time.monotonic()-start < 90:
            pressure=subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True).strip()
            processes=subprocess.check_output(['ps','-axo','pid,ppid,%cpu,%mem,rss,comm'],text=True).splitlines()
            top=sorted(processes[1:],key=lambda l:float(l.split()[2]),reverse=True)[:15]
            m.write(json.dumps({'tick':time.monotonic_ns(),'pressure':pressure,'top':top})+'\n');m.flush()
            if pressure != '1':manifest['interrupted']='memory pressure';game.terminate();break
            time.sleep(2)
        if game.poll() is None:manifest.setdefault('interrupted','timeout');game.terminate()
        manifest['game_exit']=game.wait(timeout=15)
except BaseException as e:manifest['failure']=repr(e)
finally:
    if game and game.poll() is None:
        game.terminate()
        try:game.wait(timeout=10)
        except subprocess.TimeoutExpired:game.kill();game.wait()
    manifest['end_monotonic_ns']=time.monotonic_ns()
    (out/'run.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest,indent=2))
