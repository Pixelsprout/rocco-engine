import sys,csv,json
from pathlib import Path
sys.path.insert(0,str(Path('bench').resolve()))
import analyse
root=Path('/tmp/rocco-instancing-bench-final');protocol=json.loads((root/'protocol.json').read_text());protocol['machine']=json.loads(protocol['machine']) if isinstance(protocol['machine'],str) else protocol['machine'];(root/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
summary={}
for game in ['draws','mixed']:
 summary[game]={}
 for n in protocol['ns']:
  summary[game][str(n)]={}
  for variant in ['baseline','candidate']:
   processes=[]
   for pair in range(protocol['processes']):
    with (root/f'{game}-{n}-{pair}-{variant}.csv').open() as f:rows=list(csv.DictReader(f))
    assert len(rows)==protocol['warmup_frames']+protocol['measured_frames']
    processes.append(rows[protocol['warmup_frames']:])
   spans=[k for k in processes[0][0] if k.endswith('_us') and k!='span_cost_us']
   s={k:analyse.stats_of([[float(r[k]) for r in rows] for rows in processes]) for k in spans}
   s['frame_budget_us']=analyse.stats_of([[analyse.frame_budget(r,spans) for r in rows] for rows in processes])
   s['frame_cpu_us']=analyse.stats_of([[sum(float(r[k]) for k in spans) for r in rows] for rows in processes])
   s['samples']=protocol['processes']*protocol['measured_frames'];summary[game][str(n)][variant]=s
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for game in summary:
 for n,row in summary[game].items():
  a,b=row['baseline'],row['candidate'];ar,br=a['render_submit_us'],b['render_submit_us']
  print(game,n,'submit med',round(ar['median'],3),round(br['median'],3),'submit p95',round(ar['p95'],3),round(br['p95'],3),'us/draw',round(ar['median']/int(n),5),round(br['median']/int(n),5),'budget p99',round(a['frame_budget_us']['p99'],3),round(b['frame_budget_us']['p99'],3),'cpu p95',round(a['frame_cpu_us']['p95'],3),round(b['frame_cpu_us']['p95'],3))
