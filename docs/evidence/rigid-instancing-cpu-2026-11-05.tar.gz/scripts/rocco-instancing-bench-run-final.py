import os,json,time,subprocess,hashlib,platform,sys,csv,statistics
from pathlib import Path
root=Path.cwd();out=Path('/tmp/rocco-instancing-bench-final');sys.path.insert(0,str(root/'bench'));import machine
ns=[64,1024,16384];warm=120;measured=600;processes=3
metadata={'machine':machine.machine_info() if hasattr(machine,'machine_info') else subprocess.check_output(['python3','bench/machine.py'],text=True),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'compiler':'/tmp/rocco-pinned-odin/odin (902106f)','flags':['-o:speed','-define:ROCCO_SPANS=true','-vet','-strict-style'],'launch_policy':'taskpolicy -a for both binaries; alternating pair order; no background processes stopped','warmup_frames':warm,'measured_frames':measured,'processes':processes,'ns':ns,'runs':[],'binaries':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.bin')}}
(out/'background-processes.txt').write_text(subprocess.check_output(['ps','-axo','pid,pcpu,comm'],text=True))
for game in ['draws','mixed']:
 for n in ns:
  for pair in range(processes):
   variants=['baseline','candidate'] if pair%2==0 else ['candidate','baseline']
   for variant in variants:
    stem=f'{game}-{n}-{pair}-{variant}';command=['taskpolicy','-a',str(out/(variant+'-'+game+'.bin')),str(n)]
    env=dict(os.environ,ROCCO_SEED='0',ROCCO_LOCKSTEP='1',ROCCO_EXIT_AFTER_FRAMES=str(warm+measured),ROCCO_SPANS_CSV=str(out/(stem+'.csv')))
    print(stem,flush=True);start=time.monotonic()
    with (out/(stem+'.log')).open('w') as log:subprocess.run(command,cwd=root/'bench'/game,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
    metadata['runs'].append({'stem':stem,'command':command,'environment':{k:v for k,v in env.items() if k.startswith('ROCCO_')},'seconds':time.monotonic()-start})
    (out/'protocol.json').write_text(json.dumps(metadata,indent=2)+'\n');time.sleep(1)
def percentile(values,p):
 a=sorted(values);x=(len(a)-1)*p;lo=int(x);return a[lo]+(a[min(lo+1,len(a)-1)]-a[lo])*(x-lo)
summary={}
for game in ['draws','mixed']:
 summary[game]={}
 for n in ns:
  summary[game][str(n)]={}
  for variant in ['baseline','candidate']:
   rows=[]
   for pair in range(processes):
    with (out/f'{game}-{n}-{pair}-{variant}.csv').open() as f:rows+=list(csv.DictReader(f))[warm:]
   names=rows[0].keys();columns={name:[float(row[name]) for row in rows] for name in names}
   columns['frame_budget_us']=[2*sum(float(row[k]) for k in ['input_us','step_us','commands_us','view_us','queries_us','query_results_us'])+sum(float(row[k]) for k in ['interpolation_us','ui_layout_us','render_submit_us','commit_us']) for row in rows]
   summary[game][str(n)][variant]={k:{'median':statistics.median(v),'p95':percentile(v,.95),'p99':percentile(v,.99),'max':max(v)} for k,v in columns.items()}
   summary[game][str(n)][variant]['samples']=len(rows)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
