import os,shutil,subprocess
from pathlib import Path
root=Path.cwd();out=Path('/tmp/rocco-instancing-bench');out.mkdir(exist_ok=True)
host=root/'platform/targets/arm64mac/libhost.a';saved=out/'release-libhost.a';shutil.copy2(host,saved)
try:
 for variant,engine in [('baseline','/tmp/rocco-instancing-baseline/engine'),('candidate','engine')]:
  subprocess.run(['/tmp/rocco-pinned-odin/odin','build',engine,'-build-mode:static','-out:'+str(host),'-o:speed','-define:ROCCO_SPANS=true','-vet','-strict-style'],check=True)
  for game in ['draws','mixed']:
   subprocess.run(['roc','build','--target=arm64mac','--output='+str(out/(variant+'-'+game+'.bin')),'main.roc'],cwd=root/'bench'/game,check=True)
finally:shutil.copy2(saved,host)
